import React, { createContext, useContext, useState, useRef, useCallback, useEffect } from 'react';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currentPage, setCurrentPage] = useState('games');
  const [toasts, setToasts] = useState([]);

  // ─── Music Player State ──────────────────────────────────────────────────────
  const [currentTrack, setCurrentTrack] = useState(null);
  const [queue, setQueue] = useState([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(0.8);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState('none'); // none | one | all

  const audioRef = useRef(new Audio());

  useEffect(() => {
    const audio = audioRef.current;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onDurationChange = () => setDuration(audio.duration || 0);
    const onEnded = () => {
      if (repeat === 'one') {
        audio.currentTime = 0;
        audio.play();
      } else {
        playNext();
      }
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('durationchange', onDurationChange);
    audio.addEventListener('ended', onEnded);
    audio.volume = volume;

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('durationchange', onDurationChange);
      audio.removeEventListener('ended', onEnded);
    };
  }, [repeat, queueIndex, queue, shuffle]);

  const playTrack = useCallback(async (track, trackQueue = [], index = 0) => {
    const audio = audioRef.current;

    if (trackQueue.length) {
      setQueue(trackQueue);
      setQueueIndex(index);
    }

    setCurrentTrack(track);

    // Convert path to media URL
    let url = track.file_path;
    if (window.electron) {
      url = await window.electron.pathToMediaUrl(track.file_path);
      window.electron.addRecent('music', track.id);
    }

    audio.src = url;
    audio.volume = volume;
    audio.play().then(() => setIsPlaying(true)).catch(console.error);
  }, [volume]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true)).catch(console.error);
    }
  }, [isPlaying]);

  const playNext = useCallback(() => {
    if (!queue.length) return;
    let next;
    if (shuffle) {
      next = Math.floor(Math.random() * queue.length);
    } else {
      next = (queueIndex + 1) % (repeat === 'all' ? queue.length : queue.length);
      if (next === 0 && repeat !== 'all') { setIsPlaying(false); return; }
    }
    setQueueIndex(next);
    playTrack(queue[next], queue, next);
  }, [queue, queueIndex, shuffle, repeat]);

  const playPrev = useCallback(() => {
    if (!queue.length) return;
    const audio = audioRef.current;
    if (audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    const prev = queueIndex > 0 ? queueIndex - 1 : queue.length - 1;
    setQueueIndex(prev);
    playTrack(queue[prev], queue, prev);
  }, [queue, queueIndex]);

  const seekTo = useCallback((time) => {
    audioRef.current.currentTime = time;
    setCurrentTime(time);
  }, []);

  const setVolume = useCallback((v) => {
    audioRef.current.volume = v;
    setVolumeState(v);
  }, []);

  // ─── Toast ───────────────────────────────────────────────────────────────────
  const toast = useCallback((message, type = 'info', duration = 3000) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), duration);
  }, []);

  return (
    <AppContext.Provider value={{
      currentPage, setCurrentPage,
      toasts, toast,
      currentTrack, queue, queueIndex, isPlaying, volume, currentTime, duration, shuffle, repeat,
      setShuffle, setRepeat,
      playTrack, togglePlay, playNext, playPrev, seekTo, setVolume
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
