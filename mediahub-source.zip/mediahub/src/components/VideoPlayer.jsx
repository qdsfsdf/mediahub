import React, { useRef, useState, useEffect, useCallback } from 'react';

const fmtTime = s => {
  if (!s || isNaN(s)) return '0:00';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
               : `${m}:${sec.toString().padStart(2,'0')}`;
};

export default function VideoPlayer({ item, onClose }) {
  const videoRef = useRef();
  const containerRef = useRef();
  const progressRef = useRef();
  const hideTimer = useRef();

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(1);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [url, setUrl] = useState('');

  useEffect(() => {
    async function loadVideo() {
      if (!item) return;
      let src = item.file_path;
      if (window.electron) {
        src = await window.electron.pathToMediaUrl(item.file_path);
        // Load saved progress
        const saved = await window.electron.getVideoProgress(item.id);
        if (saved > 5) {
          setTimeout(() => {
            if (videoRef.current) videoRef.current.currentTime = saved;
          }, 300);
        }
        window.electron.addRecent('videos', item.id);
      }
      setUrl(src);
    }
    loadVideo();
  }, [item]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !url) return;
    v.src = url;
    v.play().then(() => setIsPlaying(true)).catch(console.error);
  }, [url]);

  // Save progress periodically
  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef.current && window.electron && item) {
        window.electron.saveVideoProgress(item.id, videoRef.current.currentTime);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [item]);

  // Auto-hide controls
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  }, [isPlaying]);

  useEffect(() => {
    resetHideTimer();
    return () => clearTimeout(hideTimer.current);
  }, [isPlaying]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = e => {
      if (e.key === 'Escape') onClose();
      if (e.key === ' ') { e.preventDefault(); togglePlay(); }
      if (e.key === 'ArrowLeft') { if (videoRef.current) videoRef.current.currentTime -= 10; }
      if (e.key === 'ArrowRight') { if (videoRef.current) videoRef.current.currentTime += 10; }
      if (e.key === 'ArrowUp') { setVolumeState(v => { const nv = Math.min(1, v + 0.1); videoRef.current.volume = nv; return nv; }); }
      if (e.key === 'ArrowDown') { setVolumeState(v => { const nv = Math.max(0, v - 0.1); videoRef.current.volume = nv; return nv; }); }
      if (e.key === 'f' || e.key === 'F') toggleFullscreen();
      if (e.key === 'm' || e.key === 'M') { setMuted(m => { videoRef.current.muted = !m; return !m; }); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { v.play(); setIsPlaying(true); }
    else { v.pause(); setIsPlaying(false); }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setFullscreen(true);
    } else {
      document.exitFullscreen();
      setFullscreen(false);
    }
  };

  const handleProgressClick = e => {
    const rect = progressRef.current.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    const t = ratio * duration;
    videoRef.current.currentTime = t;
    setCurrentTime(t);
  };

  const handleVolumeChange = e => {
    const v = parseFloat(e.target.value);
    videoRef.current.volume = v;
    setVolumeState(v);
    if (v === 0) setMuted(true);
    else setMuted(false);
  };

  const pct = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="video-overlay"
      onMouseMove={resetHideTimer}
      onClick={e => { if (e.target === containerRef.current || e.target === videoRef.current) togglePlay(); }}
      style={{ cursor: showControls ? 'default' : 'none' }}
    >
      <video
        ref={videoRef}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain' }}
        onTimeUpdate={e => setCurrentTime(e.target.currentTime)}
        onDurationChange={e => setDuration(e.target.duration)}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => { setIsPlaying(false); onClose(); }}
      />

      {/* Close button */}
      <button
        onClick={onClose}
        style={{
          position: 'absolute', top: 16, right: 16,
          background: 'rgba(0,0,0,0.6)', border: 'none',
          borderRadius: '50%', width: 36, height: 36,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', color: '#fff', zIndex: 10,
          opacity: showControls ? 1 : 0, transition: 'opacity 0.3s'
        }}
      >
        <CloseIcon />
      </button>

      {/* Title */}
      <div className="video-title" style={{ opacity: showControls ? 1 : 0, transition: 'opacity 0.3s', zIndex: 10 }}>
        {item?.title}
      </div>

      {/* Controls */}
      <div
        className="video-controls"
        style={{ opacity: showControls ? 1 : 0, transition: 'opacity 0.3s', zIndex: 10 }}
        onClick={e => e.stopPropagation()}
      >
        {/* Progress */}
        <div className="video-progress">
          <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, minWidth: 44 }}>{fmtTime(currentTime)}</span>
          <div
            ref={progressRef}
            className="progress-bar"
            onClick={handleProgressClick}
            style={{ flex: 1, height: 5 }}
          >
            <div className="progress-fill" style={{ width: `${pct}%` }}>
              <div className="progress-thumb" />
            </div>
          </div>
          <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, minWidth: 44, textAlign: 'right' }}>{fmtTime(duration)}</span>
        </div>

        {/* Buttons */}
        <div className="video-buttons">
          <VidBtn onClick={togglePlay} title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}>
            {isPlaying ? <PauseIcon /> : <PlayIcon />}
          </VidBtn>

          <VidBtn onClick={() => { videoRef.current.currentTime -= 10; }}>
            <SkipBackIcon />
          </VidBtn>
          <VidBtn onClick={() => { videoRef.current.currentTime += 10; }}>
            <SkipFwdIcon />
          </VidBtn>

          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 8 }}>
            <VidBtn onClick={() => { setMuted(m => { videoRef.current.muted = !m; return !m; });}}>
              {muted || volume === 0 ? <MuteIcon /> : <VolumeIcon />}
            </VidBtn>
            <input
              type="range" min="0" max="1" step="0.05" value={muted ? 0 : volume}
              onChange={handleVolumeChange}
              style={{ width: 80, accentColor: 'var(--accent)', cursor: 'pointer' }}
            />
          </div>

          <div style={{ flex: 1 }} />

          <VidBtn onClick={toggleFullscreen} title="Fullscreen (F)">
            {fullscreen ? <ExitFsIcon /> : <FsIcon />}
          </VidBtn>
        </div>
      </div>
    </div>
  );
}

function VidBtn({ onClick, children, title }) {
  return (
    <button
      onClick={onClick}
      title={title}
      style={{
        background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.85)',
        cursor: 'pointer', padding: '6px 8px', borderRadius: 6, display: 'flex',
        alignItems: 'center', justifyContent: 'center', transition: 'color 0.15s',
      }}
      onMouseEnter={e => e.currentTarget.style.color = '#fff'}
      onMouseLeave={e => e.currentTarget.style.color = 'rgba(255,255,255,0.85)'}
    >
      {children}
    </button>
  );
}

const PlayIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const PauseIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>;
const SkipBackIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 4v16"/><path d="M15 4l-9 8 9 8V4z"/><text x="16" y="16" fontSize="7" fill="currentColor" stroke="none">10</text></svg>;
const SkipFwdIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v16"/><path d="M9 4l9 8-9 8V4z"/></svg>;
const VolumeIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>;
const MuteIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>;
const FsIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>;
const ExitFsIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></svg>;
const CloseIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
