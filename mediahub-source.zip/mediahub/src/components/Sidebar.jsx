import React from 'react';
import { useApp } from '../context/AppContext.jsx';

const nav = [
  {
    label: 'Library',
    items: [
      { id: 'games',   label: 'Games',    icon: GameIcon,   color: '#f59e0b' },
      { id: 'music',   label: 'Music',    icon: MusicIcon,  color: '#8b5cf6' },
      { id: 'videos',  label: 'Videos',   icon: VideoIcon,  color: '#3b82f6' },
      { id: 'movies',  label: 'Movies',   icon: MovieIcon,  color: '#ec4899' },
      { id: 'tvshows', label: 'TV Shows', icon: TVIcon,     color: '#10b981' },
      { id: 'other',   label: 'Other',    icon: FolderIcon, color: '#6b7280' },
    ]
  },
  {
    label: 'System',
    items: [
      { id: 'settings', label: 'Settings', icon: SettingsIcon, color: '#6b7280' },
    ]
  }
];

export default function Sidebar() {
  const { currentPage, setCurrentPage } = useApp();

  return (
    <aside className="sidebar">
      <nav className="sidebar-nav">
        {nav.map(group => (
          <div key={group.label}>
            <div className="sidebar-section-label">{group.label}</div>
            {group.items.map(item => (
              <div
                key={item.id}
                className={`sidebar-item${currentPage === item.id ? ' active' : ''}`}
                onClick={() => setCurrentPage(item.id)}
              >
                <span className="sidebar-item-icon" style={{ color: currentPage === item.id ? item.color : undefined }}>
                  <item.icon />
                </span>
                {item.label}
              </div>
            ))}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div style={{ padding: '8px 16px', fontSize: 11, color: 'var(--text-muted)' }}>
          MediaHub v1.0
        </div>
      </div>
    </aside>
  );
}

// ─── Icons (Inline SVG) ───────────────────────────────────────────────────────
function GameIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="2" y="6" width="20" height="12" rx="2"/>
    <path d="M12 12h.01M17 12h.01M7 9v6M4 12h6"/>
  </svg>;
}

function MusicIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>
  </svg>;
}

function VideoIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>
  </svg>;
}

function MovieIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="2" y="2" width="20" height="20" rx="2"/>
    <path d="M7 2v20M17 2v20M2 12h20M2 7h5M17 7h5M2 17h5M17 17h5"/>
  </svg>;
}

function TVIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="2" y="7" width="20" height="15" rx="2"/><polyline points="17 2 12 7 7 2"/>
  </svg>;
}

function FolderIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
  </svg>;
}

function SettingsIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
  </svg>;
}
