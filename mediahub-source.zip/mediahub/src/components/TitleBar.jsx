import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.jsx';

// Inline SVG icons to avoid dependencies
const SearchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
  </svg>
);

const MinimizeIcon = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
    <rect y="4.5" width="10" height="1"/>
  </svg>
);

const MaximizeIcon = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1">
    <rect x="0.5" y="0.5" width="9" height="9"/>
  </svg>
);

const CloseIcon = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M1 1l8 8M9 1l-8 8"/>
  </svg>
);

const LogoIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
  </svg>
);

export default function TitleBar() {
  const { setCurrentPage } = useApp();
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    if (!search.trim() || !window.electron) {
      setSearchResults([]);
      setShowResults(false);
      return;
    }
    const timer = setTimeout(async () => {
      const results = await window.electron.search(search);
      setSearchResults(results);
      setShowResults(true);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const typeLabel = { games:'🎮', music:'🎵', videos:'📹', movies:'🎬', tvshows:'📺', other:'📁' };

  return (
    <div className="titlebar">
      <div className="titlebar-left">
        <div className="titlebar-logo">
          <LogoIcon />
          <span className="titlebar-title">MediaHub</span>
        </div>
      </div>

      <div className="titlebar-center" style={{ position: 'relative' }}>
        <div className="search-bar" style={{ WebkitAppRegion: 'no-drag' }}>
          <SearchIcon />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search library..."
            onBlur={() => setTimeout(() => setShowResults(false), 200)}
            onFocus={() => search && setShowResults(true)}
          />
        </div>

        {showResults && searchResults.length > 0 && (
          <div style={{
            position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)',
            marginTop: 4, background: 'var(--bg-elevated)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-lg)', padding: 6, width: 340, zIndex: 9999,
            boxShadow: 'var(--shadow-lg)', WebkitAppRegion: 'no-drag'
          }}>
            {searchResults.slice(0, 8).map(r => (
              <div
                key={r.id}
                className="context-item"
                onMouseDown={() => {
                  setCurrentPage(r.type);
                  setSearch('');
                  setShowResults(false);
                }}
              >
                <span style={{ fontSize: 16 }}>{typeLabel[r.type] || '📄'}</span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{r.type}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="titlebar-controls">
        <button className="titlebar-btn" onClick={() => window.electron?.minimize()} title="Minimize">
          <MinimizeIcon />
        </button>
        <button className="titlebar-btn" onClick={() => window.electron?.maximize()} title="Maximize">
          <MaximizeIcon />
        </button>
        <button className="titlebar-btn close" onClick={() => window.electron?.close()} title="Close">
          <CloseIcon />
        </button>
      </div>
    </div>
  );
}
