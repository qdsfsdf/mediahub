import React, { useRef } from 'react';
import { useApp } from '../context/AppContext.jsx';

const fmtTime = s => {
  if (!s || isNaN(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2,'0')}`;
};

export default function MusicPlayer() {
  const {
    currentTrack, isPlaying, volume, currentTime, duration, shuffle, repeat,
    togglePlay, playNext, playPrev, seekTo, setVolume, setShuffle, setRepeat
  } = useApp();

  const progressRef = useRef();
  const volumeRef = useRef();

  if (!currentTrack) return null;

  const pct = duration ? (currentTime / duration) * 100 : 0;
  const volPct = volume * 100;

  const handleProgressClick = e => {
    const rect = progressRef.current.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    seekTo(ratio * duration);
  };

  const handleVolumeClick = e => {
    const rect = volumeRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setVolume(ratio);
  };

  const meta = currentTrack.metadata || {};
  const art = currentTrack.cover_art;

  const nextRepeat = { none: 'all', all: 'one', one: 'none' };

  return (
    <div className="music-player">
      {/* Track Info */}
      <div className="player-track">
        <div className="player-art">
          {art
            ? <img src={art} alt="" onError={e => e.target.style.display='none'} />
            : <PlaceholderArt />
          }
        </div>
        <div className="player-track-info">
          <div className="player-track-title">{currentTrack.title}</div>
          <div className="player-track-artist">{meta.artist || 'Unknown Artist'}</div>
        </div>
        <HeartBtn trackId={currentTrack.id} />
      </div>

      {/* Controls */}
      <div className="player-controls">
        <div className="player-buttons">
          <button
            className={`player-btn${shuffle ? ' active' : ''}`}
            onClick={() => setShuffle(s => !s)}
            title="Shuffle"
          >
            <ShuffleIcon />
          </button>

          <button className="player-btn" onClick={playPrev} title="Previous">
            <PrevIcon />
          </button>

          <button className="player-btn-play" onClick={togglePlay} title={isPlaying ? 'Pause' : 'Play'}>
            {isPlaying ? <PauseIcon /> : <PlayIcon />}
          </button>

          <button className="player-btn" onClick={playNext} title="Next">
            <NextIcon />
          </button>

          <button
            className={`player-btn${repeat !== 'none' ? ' active' : ''}`}
            onClick={() => setRepeat(r => nextRepeat[r])}
            title={`Repeat: ${repeat}`}
          >
            {repeat === 'one' ? <RepeatOneIcon /> : <RepeatIcon />}
          </button>
        </div>

        <div className="player-progress">
          <span className="player-time">{fmtTime(currentTime)}</span>
          <div
            ref={progressRef}
            className="progress-bar"
            onClick={handleProgressClick}
          >
            <div className="progress-fill" style={{ width: `${pct}%` }}>
              <div className="progress-thumb" />
            </div>
          </div>
          <span className="player-time end">{fmtTime(duration)}</span>
        </div>
      </div>

      {/* Volume */}
      <div className="player-volume">
        <button className="player-btn" onClick={() => setVolume(v => v > 0 ? 0 : 0.8)}>
          {volume === 0 ? <MuteIcon /> : <VolumeIcon />}
        </button>
        <div
          ref={volumeRef}
          className="volume-slider"
          onClick={handleVolumeClick}
        >
          <div className="volume-fill" style={{ width: `${volPct}%` }} />
        </div>
      </div>
    </div>
  );
}

function HeartBtn({ trackId }) {
  const [fav, setFav] = React.useState(false);
  const toggle = async () => {
    if (window.electron) {
      const result = await window.electron.toggleFavorite('music', trackId);
      setFav(result);
    }
  };
  return (
    <button className={`player-btn${fav ? ' active' : ''}`} onClick={toggle} style={{ marginLeft: 4 }}>
      <HeartIcon filled={fav} />
    </button>
  );
}

function PlaceholderArt() {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg-elevated)', color: 'var(--text-muted)', fontSize: 20 }}>
      🎵
    </div>
  );
}

// ─── Icons ────────────────────────────────────────────────────────────────────
const PlayIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const PauseIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>;
const PrevIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5" stroke="currentColor" strokeWidth="2"/></svg>;
const NextIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" strokeWidth="2"/></svg>;
const ShuffleIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>;
const RepeatIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>;
const RepeatOneIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4" strokeLinecap="round"/></svg>;
const VolumeIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>;
const MuteIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>;
const HeartIcon = ({ filled }) => <svg width="14" height="14" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
