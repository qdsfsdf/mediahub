import React, { useState } from 'react';

const PlayIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const HeartIcon = ({ filled }) => <svg width="12" height="12" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
const MoreIcon = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>;

// Emoji placeholders by type
const PLACEHOLDERS = {
  games: '🎮', music: '🎵', videos: '📹', movies: '🎬', tvshows: '📺', other: '📄'
};

const LAUNCHER_COLORS = {
  steam: '#7a7aff', epic: '#ccc', gog: '#c87ee0', manual: '#10b981'
};

export function MediaCard({ item, type, onPlay, onFavorite, onContextMenu, badge, thumbRatio = '2/3' }) {
  const [imgError, setImgError] = useState(false);
  const meta = item.metadata || {};
  const isFav = item.is_favorite;

  const subLabel = (() => {
    if (type === 'music') return meta.artist || 'Unknown Artist';
    if (type === 'games') return meta.launcher ? meta.launcher.charAt(0).toUpperCase() + meta.launcher.slice(1) : '';
    if (type === 'movies') return meta.year || '';
    if (type === 'tvshows') return meta.series || '';
    if (type === 'videos') return meta.size || '';
    return meta.format || '';
  })();

  return (
    <div
      className="media-card"
      onClick={onPlay}
      onContextMenu={onContextMenu}
    >
      <div className="media-card-thumb" style={{ aspectRatio: thumbRatio }}>
        {item.cover_art && !imgError
          ? <img src={item.cover_art} alt={item.title} onError={() => setImgError(true)} />
          : <div className="media-card-placeholder">{PLACEHOLDERS[type] || '📄'}</div>
        }

        <div className="media-card-overlay">
          <button className="media-card-play" onClick={e => { e.stopPropagation(); onPlay?.(); }}>
            <PlayIcon />
          </button>
        </div>

        {/* Progress bar for videos */}
        {item.video_progress > 0 && (
          <div className="media-card-progress">
            <div
              className="media-card-progress-bar"
              style={{ width: `${Math.min(100, item.video_progress)}%` }}
            />
          </div>
        )}

        {/* Launcher badge */}
        {type === 'games' && meta.launcher && (
          <div className="media-card-badge" style={{ color: LAUNCHER_COLORS[meta.launcher] || '#ccc' }}>
            {meta.launcher.toUpperCase()}
          </div>
        )}

        {/* Format badge for other types */}
        {badge && (
          <div className="media-card-badge">{badge}</div>
        )}

        {/* Favorite */}
        <button
          className={`media-card-fav${isFav ? ' active' : ''}`}
          onClick={e => { e.stopPropagation(); onFavorite?.(); }}
          title={isFav ? 'Remove from favorites' : 'Add to favorites'}
        >
          <HeartIcon filled={isFav} />
        </button>
      </div>

      <div className="media-card-info">
        <div className="media-card-title" title={item.title}>{item.title}</div>
        {subLabel && <div className="media-card-sub">{subLabel}</div>}
        {type === 'music' && meta.durationStr && (
          <div className="media-card-sub" style={{ color: 'var(--text-muted)', fontSize: 11 }}>
            {meta.album || ''}{meta.album && meta.durationStr ? ' · ' : ''}{meta.durationStr}
          </div>
        )}
      </div>
    </div>
  );
}

export function MediaListItem({ item, type, index, isPlaying, onPlay, onFavorite, onContextMenu, extra }) {
  const [imgError, setImgError] = useState(false);
  const meta = item.metadata || {};
  const isFav = item.is_favorite;

  const subLabel = (() => {
    if (type === 'music') return [meta.artist, meta.album].filter(Boolean).join(' — ');
    if (type === 'games') return meta.directory || '';
    if (type === 'videos' || type === 'movies') return meta.size || '';
    if (type === 'tvshows') return meta.series ? `S${String(meta.season || 0).padStart(2,'0')}E${String(meta.episode || 0).padStart(2,'0')}` : '';
    return meta.format || '';
  })();

  return (
    <div
      className={`media-list-item${isPlaying ? ' playing' : ''}`}
      onClick={onPlay}
      onContextMenu={onContextMenu}
    >
      {index !== undefined && (
        <div className="media-list-num">
          {isPlaying
            ? <PlayingBars />
            : <span>{index + 1}</span>
          }
        </div>
      )}

      <div className="media-list-thumb">
        {item.cover_art && !imgError
          ? <img src={item.cover_art} alt={item.title} onError={() => setImgError(true)} />
          : <div style={{ width:'100%',height:'100%',display:'flex',alignItems:'center',justifyContent:'center',
              background:'var(--bg-elevated)',fontSize:20 }}>
              {PLACEHOLDERS[type] || '📄'}
            </div>
        }
      </div>

      <div className="media-list-info">
        <div className="media-list-title" style={{ color: isPlaying ? 'var(--accent)' : undefined }}>
          {item.title}
        </div>
        {subLabel && <div className="media-list-sub">{subLabel}</div>}
      </div>

      <div className="media-list-meta">
        {extra}
        {type === 'music' && meta.durationStr && (
          <span className="media-list-duration">{meta.durationStr}</span>
        )}
        {type === 'games' && meta.launcher && (
          <span className="launcher-badge" style={{ background: 'rgba(255,255,255,0.05)', color: LAUNCHER_COLORS[meta.launcher] }}>
            {meta.launcher}
          </span>
        )}
        {type === 'other' && meta.format && (
          <span style={{ fontSize: 11, color: 'var(--text-muted)', background: 'var(--bg-elevated)',
            padding: '2px 7px', borderRadius: 4 }}>{meta.format}</span>
        )}
        {type === 'other' && meta.size && (
          <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{meta.size}</span>
        )}
      </div>

      <div className="media-list-actions">
        <button
          className={`btn btn-icon${isFav ? ' active' : ''}`}
          onClick={e => { e.stopPropagation(); onFavorite?.(); }}
          title="Favorite"
          style={{ width: 28, height: 28 }}
        >
          <HeartIcon filled={isFav} />
        </button>
        <button
          className="btn btn-icon"
          onClick={e => { e.stopPropagation(); onContextMenu?.(e); }}
          style={{ width: 28, height: 28 }}
        >
          <MoreIcon />
        </button>
      </div>
    </div>
  );
}

function PlayingBars() {
  return (
    <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 14, justifyContent: 'center' }}>
      {[1,2,3].map(i => (
        <div key={i} style={{
          width: 3, background: 'var(--accent)', borderRadius: 1,
          animation: `playbar${i} 0.8s ease-in-out infinite alternate`,
          height: i === 2 ? 14 : i === 1 ? 8 : 11
        }} />
      ))}
      <style>{`
        @keyframes playbar1 { to { height: 14px } }
        @keyframes playbar2 { to { height: 6px } }
        @keyframes playbar3 { to { height: 14px } }
      `}</style>
    </div>
  );
}

export function ContextMenu({ x, y, items, onClose }) {
  React.useEffect(() => {
    const handler = () => onClose();
    window.addEventListener('click', handler);
    window.addEventListener('contextmenu', handler);
    return () => { window.removeEventListener('click', handler); window.removeEventListener('contextmenu', handler); };
  }, [onClose]);

  return (
    <div
      className="context-menu"
      style={{ left: x, top: y }}
      onClick={e => e.stopPropagation()}
    >
      {items.map((item, i) => (
        item.sep
          ? <div key={i} className="context-sep" />
          : <div
              key={i}
              className={`context-item${item.danger ? ' danger' : ''}`}
              onClick={() => { item.onClick(); onClose(); }}
            >
              {item.icon && <span style={{ width: 16, display: 'flex', alignItems: 'center' }}>{item.icon}</span>}
              {item.label}
            </div>
      ))}
    </div>
  );
}
