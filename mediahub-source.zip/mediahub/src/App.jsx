import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext.jsx';
import TitleBar from './components/TitleBar.jsx';
import Sidebar from './components/Sidebar.jsx';
import MusicPlayer from './components/MusicPlayer.jsx';
import ToastContainer from './components/ToastContainer.jsx';

import Games from './pages/Games.jsx';
import Music from './pages/Music.jsx';
import Videos from './pages/Videos.jsx';
import Movies from './pages/Movies.jsx';
import TVShows from './pages/TVShows.jsx';
import OtherFiles from './pages/OtherFiles.jsx';
import Settings from './pages/Settings.jsx';

function AppShell() {
  const { currentPage, currentTrack } = useApp();

  const pages = {
    games: <Games />,
    music: <Music />,
    videos: <Videos />,
    movies: <Movies />,
    tvshows: <TVShows />,
    other: <OtherFiles />,
    settings: <Settings />
  };

  return (
    <div className="app-shell">
      <TitleBar />
      <div className="app-body">
        <Sidebar />
        <main className={`app-content${currentTrack ? ' with-player' : ''}`}>
          <div className="fade-in" key={currentPage}>
            {pages[currentPage] || <Games />}
          </div>
        </main>
      </div>
      {currentTrack && <MusicPlayer />}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
