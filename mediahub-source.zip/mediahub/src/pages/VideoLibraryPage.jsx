import React, { useState, useEffect, useCallback } from 'react';
import { MediaCard, MediaListItem, ContextMenu } from '../components/MediaCard.jsx';
import VideoPlayer from '../components/VideoPlayer.jsx';
import { useApp } from '../context/AppContext.jsx';

const ScanIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>;
const GridIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>;
const ListIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>;

export default function VideoLibraryPage({ type, title, icon, thumbRatio = '2/3' }) {
  const { toast } = useApp();
  const [items, setItems] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('grid');
  const [filter, setFilter] = useState('all');
  const [scanning, setScanning] = useState('');
  const [playing, setPlaying] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);
  const [selected, setSelected] = useState(null);

  const load = useCallback(async () => {
    if (!window.electron) return;
    const data = await window.electron.getLibrary(type);
    // Attach progress percentage
    const withProgress = data.map(item => ({
      ...item,
      video_progress: item.video_progress
        ? Math.round((item.video_progress / (item.metadata?.duration || 1)) * 100)
        : 0
    }));
    setItems(withProgress);
    setFiltered(withProgress);
  }, [type]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!window.electron) return;
    const off = window.electron.onScanProgress(d => {
      if (d.type === type) setScanning(`Scanning… ${d.count} files found`);
    });
    return off;
  }, [type]);

  useEffect(() => {
    let result = items;
    if (filter === 'favorites') result = result.filter(i => i.is_favorite);
    if (filter === 'in-progress') result = result.filter(i => i.video_progress > 0 && i.video_progress < 95);
    if (search) result = result.filter(i => i.title.toLowerCase().includes(search.toLowerCase()));
    setFiltered(result);
  }, [items, search, filter]);

  const handleScan = async () => {
    setScanning('Starting scan…');
    const result = await window.electron.scanLibrary(type);
    setScanning('');
    toast(`Found ${result.count} files`, 'success');
    load();
  };

  const toggleFavorite = async (item) => {
    const result = await window.electron.toggleFavorite(type, item.id);
    setItems(prev => prev.map(i => i.id === item.id ? { ...i, is_favorite: result ? 1 : 0 } : i));
  };

  const deleteItem = async (item) => {
    if (confirm(`Remove "${item.title}" from library?`)) {
      await window.electron.deleteItem(type, item.id);
      load();
    }
  };

  const openInPlayer = (item) => {
    setPlaying(item);
    window.electron?.addRecent(type, item.id);
  };

  // TV Show grouping
  const tvGroups = React.useMemo(() => {
    if (type !== 'tvshows') return null;
    const map = {};
    for (const item of filtered) {
      const series = item.metadata?.series || item.title;
      if (!map[series]) map[series] = { name: series, items: [], cover: item.cover_art };
      map[series].items.push(item);
    }
    return Object.values(map).sort((a, b) => a.name.localeCompare(b.name));
  }, [filtered, type]);

  return (
    <>
      <div className="page">
        {scanning && (
          <div className="scan-banner">
            <div className="scan-spinner" />
            <span>{scanning}</span>
          </div>
        )}

        <div className="page-header">
          <div className="page-header-left">
            <h1 className="page-title">{title}</h1>
            <p className="page-subtitle">{items.length} {type === 'tvshows' ? 'episodes' : 'files'}</p>
          </div>
          <div className="page-header-right">
            <button className="btn btn-secondary btn-sm" onClick={handleScan}>
              <ScanIcon /> Scan
            </button>
            <div className="view-toggle">
              <button className={`view-toggle-btn${view === 'grid' ? ' active' : ''}`} onClick={() => setView('grid')}><GridIcon /></button>
              <button className={`view-toggle-btn${view === 'list' ? ' active' : ''}`} onClick={() => setView('list')}><ListIcon /></button>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
          <div className="search-bar">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={`Search ${title.toLowerCase()}…`}
              style={{ width: 200 }}
            />
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['all', 'favorites', 'in-progress'].map(f => (
              <span key={f} className={`chip${filter === f ? ' active' : ''}`} onClick={() => setFilter(f)}>
                {f === 'all' ? 'All' : f === 'favorites' ? '♥ Favorites' : '⏸ In Progress'}
              </span>
            ))}
          </div>
        </div>

        {/* Content */}
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">{icon}</div>
            <h3>{search ? `No ${title.toLowerCase()} found` : `No ${title.toLowerCase()} yet`}</h3>
            <p>{search ? 'Try a different search.' : `Add ${title.toLowerCase()} folders in Settings, then scan.`}</p>
            {!search && <button className="btn btn-primary" onClick={handleScan}><ScanIcon /> Scan Folders</button>}
          </div>
        ) : type === 'tvshows' && tvGroups ? (
          <TVShowGrid groups={tvGroups} onPlay={openInPlayer} onFavorite={toggleFavorite} />
        ) : view === 'grid' ? (
          <div className="media-grid">
            {filtered.map(item => (
              <MediaCard
                key={item.id} item={item} type={type} thumbRatio={thumbRatio}
                onPlay={() => openInPlayer(item)}
                onFavorite={() => toggleFavorite(item)}
                onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelected(item); }}
                badge={item.metadata?.format}
              />
            ))}
          </div>
        ) : (
          <div className="media-list">
            {filtered.map((item, i) => (
              <MediaListItem
                key={item.id} item={item} type={type} index={i}
                onPlay={() => openInPlayer(item)}
                onFavorite={() => toggleFavorite(item)}
                onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelected(item); }}
              />
            ))}
          </div>
        )}

        {/* Context Menu */}
        {contextMenu && selected && (
          <ContextMenu
            x={contextMenu.x} y={contextMenu.y}
            onClose={() => setContextMenu(null)}
            items={[
              { label: 'Play', icon: '▶', onClick: () => openInPlayer(selected) },
              { label: selected.is_favorite ? 'Remove Favorite' : 'Add to Favorites', icon: '♥', onClick: () => toggleFavorite(selected) },
              { sep: true },
              { label: 'Show in Explorer', icon: '📁', onClick: () => window.electron.showInFolder(selected.file_path) },
              { sep: true },
              { label: 'Remove from Library', danger: true, icon: '✕', onClick: () => deleteItem(selected) },
            ]}
          />
        )}
      </div>

      {/* Video Player */}
      {playing && (
        <VideoPlayer
          item={playing}
          onClose={() => { setPlaying(null); load(); }}
        />
      )}
    </>
  );
}

function TVShowGrid({ groups, onPlay, onFavorite }) {
  const [expanded, setExpanded] = useState(null);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {groups.map(group => (
        <div key={group.name} style={{ background: 'var(--bg-card)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)', overflow: 'hidden' }}>
          <div
            style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', cursor: 'pointer', userSelect: 'none' }}
            onClick={() => setExpanded(expanded === group.name ? null : group.name)}
          >
            <div style={{ width: 52, height: 52, borderRadius: 'var(--radius-sm)', overflow: 'hidden', background: 'var(--bg-elevated)', flexShrink: 0 }}>
              {group.cover
                ? <img src={group.cover} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>📺</div>
              }
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{group.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{group.items.length} episode{group.items.length !== 1 ? 's' : ''}</div>
            </div>
            <span style={{ color: 'var(--text-muted)', fontSize: 12, transform: expanded === group.name ? 'rotate(90deg)' : '', transition: 'transform 0.2s', display: 'inline-block' }}>▶</span>
          </div>

          {expanded === group.name && (
            <div style={{ borderTop: '1px solid var(--border)' }}>
              <div className="media-list" style={{ padding: '8px 0' }}>
                {group.items
                  .sort((a, b) => {
                    const sa = (a.metadata?.season || 0) * 1000 + (a.metadata?.episode || 0);
                    const sb = (b.metadata?.season || 0) * 1000 + (b.metadata?.episode || 0);
                    return sa - sb;
                  })
                  .map((item, i) => (
                    <MediaListItem
                      key={item.id} item={item} type="tvshows" index={i}
                      onPlay={() => onPlay(item)}
                      onFavorite={() => onFavorite(item)}
                      extra={item.metadata?.season ? (
                        <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'monospace' }}>
                          S{String(item.metadata.season).padStart(2,'0')}E{String(item.metadata.episode || 0).padStart(2,'0')}
                        </span>
                      ) : null}
                    />
                  ))
                }
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
