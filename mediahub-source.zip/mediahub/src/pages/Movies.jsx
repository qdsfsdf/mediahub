import React from 'react';
import VideoLibraryPage from './VideoLibraryPage.jsx';

export default function Movies() {
  return <VideoLibraryPage type="movies" title="Movies" icon="🎬" thumbRatio="2/3" />;
}
