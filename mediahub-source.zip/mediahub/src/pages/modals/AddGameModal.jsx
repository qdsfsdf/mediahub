import React, { useState } from 'react';

export default function AddGameModal({ onClose, onAdd }) {
  const [title, setTitle] = useState('');
  const [exePath, setExePath] = useState('');
  const [coverArt, setCoverArt] = useState(null);

  const selectExe = async () => {
    const f = await window.electron.selectFile([{ name: 'Executables', extensions: ['exe'] }]);
    if (f) {
      setExePath(f);
      if (!title) {
        const parts = f.split(/[\\/]/);
        const name = parts[parts.length - 1].replace('.exe', '').replace(/[_-]/g, ' ');
        setTitle(name);
      }
    }
  };

  const selectCover = async () => {
    const img = await window.electron.selectImage();
    if (img) setCoverArt(img);
  };

  const save = async () => {
    if (!title.trim() || !exePath) return;
    await window.electron.addItem('games', {
      title: title.trim(),
      file_path: exePath,
      cover_art: coverArt,
      metadata: { launcher: 'manual', directory: exePath.replace(/[^/\\]+$/, '') }
    });
    onAdd();
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">Add Game</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}>✕</button>
        </div>

        <div style={{ display: 'flex', gap: 16 }}>
          {/* Cover Art */}
          <div
            onClick={selectCover}
            style={{
              width: 100, height: 140, borderRadius: 'var(--radius)', overflow: 'hidden',
              background: 'var(--bg-elevated)', border: '1px solid var(--border)',
              cursor: 'pointer', flexShrink: 0, display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 32, color: 'var(--text-muted)',
              transition: 'border-color 0.15s'
            }}
          >
            {coverArt ? <img src={coverArt} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🖼'}
          </div>

          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label className="label">Game Title *</label>
              <input
                className="input"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Enter game title"
              />
            </div>

            <div>
              <label className="label">Executable Path *</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  className="input"
                  value={exePath}
                  onChange={e => setExePath(e.target.value)}
                  placeholder="C:\Games\game.exe"
                  style={{ flex: 1 }}
                />
                <button className="btn btn-secondary btn-sm" onClick={selectExe} style={{ flexShrink: 0 }}>
                  Browse
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={!title.trim() || !exePath}>
            Add Game
          </button>
        </div>
      </div>
    </div>
  );
}
