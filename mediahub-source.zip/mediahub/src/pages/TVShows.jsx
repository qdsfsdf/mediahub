import React from 'react';
import VideoLibraryPage from './VideoLibraryPage.jsx';

export default function TVShows() {
  return <VideoLibraryPage type="tvshows" title="TV Shows" icon="📺" thumbRatio="16/9" />;
}
