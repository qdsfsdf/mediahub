import React, { useState, useEffect, useCallback } from 'react';
import { MediaListItem, ContextMenu } from '../components/MediaCard.jsx';
import { useApp } from '../context/AppContext.jsx';

const ScanIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>;

const EXT_ICONS = {
  PDF: '📕', EPUB: '📗', CBZ: '📔', CBR: '📔',
  DOC: '📄', DOCX: '📄', TXT: '📝',
  ZIP: '📦', RAR: '📦', '7Z': '📦',
};

export default function OtherFiles() {
  const { toast } = useApp();
  const [items, setItems] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [formatFilter, setFormatFilter] = useState('all');
  const [scanning, setScanning] = useState('');
  const [contextMenu, setContextMenu] = useState(null);
  const [selected, setSelected] = useState(null);

  const load = useCallback(async () => {
    if (!window.electron) return;
    const data = await window.electron.getLibrary('other');
    setItems(data);
    setFiltered(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!window.electron) return;
    const off = window.electron.onScanProgress(d => {
      if (d.type === 'other') setScanning(`Scanning… ${d.count} files`);
    });
    return off;
  }, []);

  useEffect(() => {
    let result = items;
    if (formatFilter !== 'all') result = result.filter(i => i.metadata?.format === formatFilter);
    if (search) result = result.filter(i => i.title.toLowerCase().includes(search.toLowerCase()));
    setFiltered(result);
  }, [items, search, formatFilter]);

  const formats = [...new Set(items.map(i => i.metadata?.format).filter(Boolean))].sort();

  const handleScan = async () => {
    setScanning('Starting scan…');
    const result = await window.electron.scanLibrary('other');
    setScanning('');
    toast(`Found ${result.count} files`, 'success');
    load();
  };

  const openFile = async (item) => {
    const result = await window.electron.openFile(item.file_path);
    if (result.success) {
      window.electron.addRecent('other', item.id);
    } else {
      toast('Could not open file', 'error');
    }
  };

  const toggleFavorite = async (item) => {
    const result = await window.electron.toggleFavorite('other', item.id);
    setItems(prev => prev.map(i => i.id === item.id ? { ...i, is_favorite: result ? 1 : 0 } : i));
  };

  const deleteItem = async (item) => {
    if (confirm(`Remove "${item.title}" from library?`)) {
      await window.electron.deleteItem('other', item.id);
      load();
    }
  };

  // Group by directory
  const grouped = React.useMemo(() => {
    const map = {};
    for (const item of filtered) {
      const dir = item.metadata?.directory || 'Unknown';
      if (!map[dir]) map[dir] = [];
      map[dir].push(item);
    }
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  return (
    <div className="page">
      {scanning && (
        <div className="scan-banner">
          <div className="scan-spinner" />
          <span>{scanning}</span>
        </div>
      )}

      <div className="page-header">
        <div className="page-header-left">
          <h1 className="page-title">Other Files</h1>
          <p className="page-subtitle">{items.length} files</p>
        </div>
        <div className="page-header-right">
          <button className="btn btn-secondary btn-sm" onClick={handleScan}>
            <ScanIcon /> Scan
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="search-bar">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search files…"
            style={{ width: 180 }}
          />
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <span className={`chip${formatFilter === 'all' ? ' active' : ''}`} onClick={() => setFormatFilter('all')}>All</span>
          {formats.map(f => (
            <span key={f} className={`chip${formatFilter === f ? ' active' : ''}`} onClick={() => setFormatFilter(f)}>
              {EXT_ICONS[f] || '📄'} {f}
            </span>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">📁</div>
          <h3>{search ? 'No files found' : 'No files yet'}</h3>
          <p>{search ? 'Try a different search.' : 'Add folders containing PDFs, documents, archives and more in Settings, then scan.'}</p>
          {!search && <button className="btn btn-primary" onClick={handleScan}><ScanIcon /> Scan Folders</button>}
        </div>
      ) : (
        grouped.map(([dir, dirItems]) => (
          <div key={dir} className="section">
            <div className="section-header">
              <span className="section-title" style={{ fontSize: 11 }} title={dir}>
                📁 {dir.length > 60 ? '…' + dir.slice(-60) : dir}
              </span>
              <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{dirItems.length} files</span>
            </div>
            <div className="media-list">
              {dirItems.map((item, i) => (
                <MediaListItem
                  key={item.id} item={item} type="other" index={i}
                  onPlay={() => openFile(item)}
                  onFavorite={() => toggleFavorite(item)}
                  onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelected(item); }}
                />
              ))}
            </div>
          </div>
        ))
      )}

      {contextMenu && selected && (
        <ContextMenu
          x={contextMenu.x} y={contextMenu.y}
          onClose={() => setContextMenu(null)}
          items={[
            { label: 'Open', icon: EXT_ICONS[selected.metadata?.format] || '📄', onClick: () => openFile(selected) },
            { label: selected.is_favorite ? 'Remove Favorite' : 'Add to Favorites', icon: '♥', onClick: () => toggleFavorite(selected) },
            { sep: true },
            { label: 'Show in Explorer', icon: '📁', onClick: () => window.electron.showInFolder(selected.file_path) },
            { sep: true },
            { label: 'Remove from Library', danger: true, icon: '✕', onClick: () => deleteItem(selected) },
          ]}
        />
      )}
    </div>
  );
}
