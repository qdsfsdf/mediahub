import React, { useState, useEffect, useCallback } from 'react';
import { MediaCard, MediaListItem, ContextMenu } from '../components/MediaCard.jsx';
import { useApp } from '../context/AppContext.jsx';

const ScanIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>;
const GridIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>;
const ListIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>;
const PlayAllIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const ShuffleIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>;
const PlusIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;

export default function Music() {
  const { playTrack, currentTrack, isPlaying, toast, setShuffle } = useApp();
  const [tracks, setTracks] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('list');
  const [groupBy, setGroupBy] = useState('all'); // all | artist | album
  const [filter, setFilter] = useState('all');
  const [scanning, setScanning] = useState('');
  const [playlists, setPlaylists] = useState([]);
  const [contextMenu, setContextMenu] = useState(null);
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [showNewPlaylist, setShowNewPlaylist] = useState(false);

  const load = useCallback(async () => {
    if (!window.electron) return;
    const data = await window.electron.getLibrary('music');
    setTracks(data);
    setFiltered(data);
    const pl = await window.electron.getPlaylists();
    setPlaylists(pl);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!window.electron) return;
    const off = window.electron.onScanProgress(d => {
      if (d.type === 'music') setScanning(`Scanning… ${d.count} tracks found`);
    });
    return off;
  }, []);

  useEffect(() => {
    let result = tracks;
    if (filter === 'favorites') result = result.filter(t => t.is_favorite);
    if (search) result = result.filter(t =>
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      (t.metadata?.artist || '').toLowerCase().includes(search.toLowerCase()) ||
      (t.metadata?.album || '').toLowerCase().includes(search.toLowerCase())
    );
    setFiltered(result);
  }, [tracks, search, filter]);

  const handleScan = async () => {
    setScanning('Starting scan…');
    const result = await window.electron.scanLibrary('music');
    setScanning('');
    toast(`Found ${result.count} tracks`, 'success');
    load();
  };

  const playAll = (shuffled = false) => {
    if (!filtered.length) return;
    const list = shuffled ? [...filtered].sort(() => Math.random() - 0.5) : filtered;
    setShuffle(shuffled);
    playTrack(list[0], list, 0);
  };

  const handlePlay = (track, index) => {
    playTrack(track, filtered, index);
  };

  const toggleFavorite = async (track) => {
    const result = await window.electron.toggleFavorite('music', track.id);
    setTracks(prev => prev.map(t => t.id === track.id ? { ...t, is_favorite: result ? 1 : 0 } : t));
  };

  const addToPlaylist = async (playlistId, trackId) => {
    await window.electron.addToPlaylist(playlistId, trackId);
    toast('Added to playlist', 'success');
  };

  const createPlaylist = async () => {
    if (!newPlaylistName.trim()) return;
    await window.electron.createPlaylist(newPlaylistName.trim());
    setNewPlaylistName('');
    setShowNewPlaylist(false);
    load();
    toast('Playlist created', 'success');
  };

  // Group tracks by album for album view
  const albums = React.useMemo(() => {
    if (groupBy !== 'album') return null;
    const map = {};
    for (const t of filtered) {
      const album = t.metadata?.album || 'Unknown Album';
      if (!map[album]) map[album] = { name: album, artist: t.metadata?.artist, cover: t.cover_art, tracks: [] };
      map[album].tracks.push(t);
    }
    return Object.values(map).sort((a, b) => a.name.localeCompare(b.name));
  }, [filtered, groupBy]);

  const artists = React.useMemo(() => {
    if (groupBy !== 'artist') return null;
    const map = {};
    for (const t of filtered) {
      const artist = t.metadata?.artist || 'Unknown Artist';
      if (!map[artist]) map[artist] = { name: artist, cover: t.cover_art, tracks: [] };
      map[artist].tracks.push(t);
    }
    return Object.values(map).sort((a, b) => a.name.localeCompare(b.name));
  }, [filtered, groupBy]);

  return (
    <div className="page">
      {scanning && (
        <div className="scan-banner">
          <div className="scan-spinner" />
          <span>{scanning}</span>
        </div>
      )}

      <div className="page-header">
        <div className="page-header-left">
          <h1 className="page-title">Music</h1>
          <p className="page-subtitle">{tracks.length} tracks</p>
        </div>
        <div className="page-header-right">
          <button className="btn btn-ghost btn-sm" onClick={() => playAll(false)} disabled={!filtered.length}>
            <PlayAllIcon /> Play All
          </button>
          <button className="btn btn-ghost btn-sm" onClick={() => playAll(true)} disabled={!filtered.length}>
            <ShuffleIcon /> Shuffle
          </button>
          <button className="btn btn-secondary btn-sm" onClick={handleScan}>
            <ScanIcon /> Scan
          </button>
          <div className="view-toggle">
            <button className={`view-toggle-btn${view === 'grid' ? ' active' : ''}`} onClick={() => setView('grid')}>
              <GridIcon />
            </button>
            <button className={`view-toggle-btn${view === 'list' ? ' active' : ''}`} onClick={() => setView('list')}>
              <ListIcon />
            </button>
          </div>
        </div>
      </div>

      {/* Controls row */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="search-bar">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search tracks, artists, albums…"
            style={{ width: 220 }}
          />
        </div>

        <div style={{ display: 'flex', gap: 6 }}>
          {['all','favorites'].map(f => (
            <span key={f} className={`chip${filter === f ? ' active' : ''}`} onClick={() => setFilter(f)}>
              {f === 'all' ? 'All' : '♥ Favorites'}
            </span>
          ))}
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
          {['all','artist','album'].map(g => (
            <span key={g} className={`chip${groupBy === g ? ' active' : ''}`} onClick={() => setGroupBy(g)}>
              {g === 'all' ? 'All Tracks' : g === 'artist' ? 'By Artist' : 'By Album'}
            </span>
          ))}
        </div>
      </div>

      {/* Playlists sidebar row */}
      {playlists.length > 0 && (
        <div className="section">
          <div className="section-header">
            <span className="section-title">Playlists</span>
            <button className="btn btn-ghost btn-sm" onClick={() => setShowNewPlaylist(true)}>
              <PlusIcon /> New
            </button>
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {playlists.map(pl => (
              <PlaylistChip key={pl.id} playlist={pl} onClick={() => {}} onDelete={() => { window.electron.deletePlaylist(pl.id); load(); }} />
            ))}
          </div>
        </div>
      )}

      {showNewPlaylist && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center' }}>
          <input
            className="input" style={{ maxWidth: 220 }}
            value={newPlaylistName}
            onChange={e => setNewPlaylistName(e.target.value)}
            placeholder="Playlist name"
            onKeyDown={e => e.key === 'Enter' && createPlaylist()}
            autoFocus
          />
          <button className="btn btn-primary btn-sm" onClick={createPlaylist}>Create</button>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowNewPlaylist(false)}>Cancel</button>
        </div>
      )}

      {/* Content */}
      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">🎵</div>
          <h3>{search ? 'No tracks found' : 'No music yet'}</h3>
          <p>{search ? 'Try a different search.' : 'Add music folders in Settings, then scan your library.'}</p>
          {!search && <button className="btn btn-primary" onClick={handleScan}><ScanIcon /> Scan Folders</button>}
        </div>
      ) : groupBy === 'album' && albums ? (
        <AlbumGrid albums={albums} onPlay={(album, i) => playTrack(album.tracks[i], album.tracks, i)} />
      ) : groupBy === 'artist' && artists ? (
        <ArtistList artists={artists} onPlay={(artist, i) => playTrack(artist.tracks[i], artist.tracks, i)} />
      ) : view === 'grid' ? (
        <div className="media-grid compact">
          {filtered.map(t => (
            <MediaCard
              key={t.id} item={t} type="music" thumbRatio="1/1"
              onPlay={() => handlePlay(t, filtered.indexOf(t))}
              onFavorite={() => toggleFavorite(t)}
              onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelectedTrack(t); }}
            />
          ))}
        </div>
      ) : (
        <div className="media-list">
          {filtered.map((t, i) => (
            <MediaListItem
              key={t.id} item={t} type="music" index={i}
              isPlaying={currentTrack?.id === t.id}
              onPlay={() => handlePlay(t, i)}
              onFavorite={() => toggleFavorite(t)}
              onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelectedTrack(t); }}
            />
          ))}
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && selectedTrack && (
        <ContextMenu
          x={contextMenu.x} y={contextMenu.y}
          onClose={() => setContextMenu(null)}
          items={[
            { label: 'Play', icon: '▶', onClick: () => handlePlay(selectedTrack, filtered.indexOf(selectedTrack)) },
            { label: selectedTrack.is_favorite ? 'Remove Favorite' : 'Add to Favorites', icon: '♥', onClick: () => toggleFavorite(selectedTrack) },
            ...(playlists.length ? [
              { sep: true },
              ...playlists.map(pl => ({
                label: `Add to "${pl.name}"`,
                onClick: () => addToPlaylist(pl.id, selectedTrack.id)
              }))
            ] : []),
            { sep: true },
            { label: 'Show in Explorer', icon: '📁', onClick: () => window.electron.showInFolder(selectedTrack.file_path) },
          ]}
        />
      )}
    </div>
  );
}

function AlbumGrid({ albums, onPlay }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div>
      <div className="media-grid">
        {albums.map(album => (
          <div key={album.name} className="media-card" onClick={() => setExpanded(expanded === album.name ? null : album.name)}>
            <div className="media-card-thumb" style={{ aspectRatio: '1/1' }}>
              {album.cover
                ? <img src={album.cover} alt={album.name} />
                : <div className="media-card-placeholder">💿</div>
              }
            </div>
            <div className="media-card-info">
              <div className="media-card-title">{album.name}</div>
              <div className="media-card-sub">{album.artist} · {album.tracks.length} tracks</div>
            </div>
          </div>
        ))}
      </div>
      {expanded && (
        <div style={{ marginTop: 16, background: 'var(--bg-card)', borderRadius: 'var(--radius-lg)', padding: 16, border: '1px solid var(--border)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', marginBottom: 12 }}>{expanded}</h3>
          <div className="media-list">
            {albums.find(a => a.name === expanded)?.tracks.map((t, i) => (
              <MediaListItem key={t.id} item={t} type="music" index={i} onPlay={() => onPlay(albums.find(a => a.name === expanded), i)} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ArtistList({ artists, onPlay }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {artists.map(artist => (
        <div key={artist.name} style={{ background: 'var(--bg-card)', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)', overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid var(--border)' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', overflow: 'hidden', background: 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>
              {artist.cover ? <img src={artist.cover} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🎤'}
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{artist.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{artist.tracks.length} tracks</div>
            </div>
            <button className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }} onClick={() => onPlay(artist, 0)}>
              ▶ Play
            </button>
          </div>
          <div className="media-list" style={{ maxHeight: 200, overflow: 'auto' }}>
            {artist.tracks.map((t, i) => (
              <MediaListItem key={t.id} item={t} type="music" index={i} onPlay={() => onPlay(artist, i)} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function PlaylistChip({ playlist, onClick, onDelete }) {
  return (
    <div className="chip" style={{ gap: 8 }} onClick={onClick}>
      🎵 {playlist.name}
      <span style={{ color: 'var(--text-muted)', fontSize: 11 }}>{playlist.track_count}</span>
      <span
        style={{ marginLeft: 2, opacity: 0.5, transition: 'opacity 0.15s' }}
        onClick={e => { e.stopPropagation(); onDelete(); }}
        onMouseEnter={e => e.currentTarget.style.opacity = 1}
        onMouseLeave={e => e.currentTarget.style.opacity = 0.5}
      >✕</span>
    </div>
  );
}
