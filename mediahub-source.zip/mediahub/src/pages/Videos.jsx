import React from 'react';
import VideoLibraryPage from './VideoLibraryPage.jsx';

export default function Videos() {
  return <VideoLibraryPage type="videos" title="Videos" icon="📹" thumbRatio="16/9" />;
}
