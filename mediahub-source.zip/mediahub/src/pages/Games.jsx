import React, { useState, useEffect, useCallback } from 'react';
import { MediaCard, MediaListItem, ContextMenu } from '../components/MediaCard.jsx';
import { useApp } from '../context/AppContext.jsx';
import AddGameModal from './modals/AddGameModal.jsx';

const ScanIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>;
const PlusIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const GridIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>;
const ListIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>;
const DetectIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;

export default function Games() {
  const { toast } = useApp();
  const [games, setGames] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('grid');
  const [filter, setFilter] = useState('all');
  const [scanning, setScanningMsg] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [contextMenu, setContextMenu] = useState(null);
  const [selectedGame, setSelectedGame] = useState(null);

  const load = useCallback(async () => {
    if (!window.electron) return;
    const data = await window.electron.getLibrary('games');
    setGames(data);
    setFiltered(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    let result = games;
    if (filter !== 'all') {
      if (filter === 'favorites') result = result.filter(g => g.is_favorite);
      else result = result.filter(g => g.metadata?.launcher === filter);
    }
    if (search) {
      result = result.filter(g => g.title.toLowerCase().includes(search.toLowerCase()));
    }
    setFiltered(result);
  }, [games, search, filter]);

  useEffect(() => {
    if (!window.electron) return;
    const off = window.electron.onScanProgress(d => {
      if (d.type === 'games') setScanningMsg(`Scanning… ${d.file}`);
    });
    return off;
  }, []);

  const handleScan = async () => {
    setScanningMsg('Starting scan…');
    const result = await window.electron.scanLibrary('games');
    setScanningMsg('');
    toast(`Found ${result.count} games`, 'success');
    load();
  };

  const handleDetect = async () => {
    setScanningMsg('Detecting launchers…');
    const result = await window.electron.detectLaunchers();
    setScanningMsg('');
    toast(`Detected ${result.count} games from launchers`, 'success');
    load();
  };

  const launchGame = async (game) => {
    if (!game.file_path) return;
    const meta = game.metadata || {};

    // Use Steam URL if available
    if (meta.steamUrl) {
      await window.electron.openFile(meta.steamUrl);
      await window.electron.addRecent('games', game.id);
      return;
    }

    const result = await window.electron.launchGame(game.file_path);
    if (result.success) {
      await window.electron.addRecent('games', game.id);
      toast(`Launched ${game.title}`, 'success');
    } else {
      toast(`Failed to launch: ${result.error}`, 'error');
    }
  };

  const toggleFavorite = async (game) => {
    const result = await window.electron.toggleFavorite('games', game.id);
    setGames(prev => prev.map(g => g.id === game.id ? { ...g, is_favorite: result ? 1 : 0 } : g));
  };

  const deleteGame = async (game) => {
    if (confirm(`Remove "${game.title}" from library?`)) {
      await window.electron.deleteItem('games', game.id);
      load();
      toast('Removed from library');
    }
  };

  const openFolder = (game) => {
    if (game.metadata?.directory) window.electron.showInFolder(game.metadata.directory);
    else if (game.file_path) window.electron.showInFolder(game.file_path);
  };

  const launchers = [...new Set(games.map(g => g.metadata?.launcher).filter(Boolean))];
  const recentGames = [...games].sort((a, b) => (b.last_opened || 0) - (a.last_opened || 0)).slice(0, 8);

  return (
    <div className="page">
      {scanning && (
        <div className="scan-banner">
          <div className="scan-spinner" />
          <span>{scanning}</span>
        </div>
      )}

      <div className="page-header">
        <div className="page-header-left">
          <h1 className="page-title">Games</h1>
          <p className="page-subtitle">{games.length} games in library</p>
        </div>
        <div className="page-header-right">
          <button className="btn btn-secondary btn-sm" onClick={handleDetect}>
            <DetectIcon /> Detect Launchers
          </button>
          <button className="btn btn-secondary btn-sm" onClick={handleScan}>
            <ScanIcon /> Scan Folders
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)}>
            <PlusIcon /> Add Game
          </button>
          <div className="view-toggle">
            <button className={`view-toggle-btn${view === 'grid' ? ' active' : ''}`} onClick={() => setView('grid')}>
              <GridIcon />
            </button>
            <button className={`view-toggle-btn${view === 'list' ? ' active' : ''}`} onClick={() => setView('list')}>
              <ListIcon />
            </button>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="search-bar" style={{ minWidth: 220 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search games…"
            style={{ width: 160 }}
          />
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['all', 'favorites', ...launchers].map(f => (
            <span
              key={f}
              className={`chip${filter === f ? ' active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f === 'all' ? 'All' : f === 'favorites' ? '♥ Favorites' : f.charAt(0).toUpperCase() + f.slice(1)}
            </span>
          ))}
        </div>
      </div>

      {/* Recently Played */}
      {filter === 'all' && !search && recentGames.length > 0 && games.length > 8 && (
        <div className="section">
          <div className="section-header">
            <span className="section-title">Recently Played</span>
          </div>
          <div className="scroll-x">
            <div className="row-scroll">
              {recentGames.map(g => (
                <MediaCard
                  key={g.id} item={g} type="games" thumbRatio="3/4"
                  onPlay={() => launchGame(g)}
                  onFavorite={() => toggleFavorite(g)}
                  onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelectedGame(g); }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* All Games */}
      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">🎮</div>
          <h3>{search ? 'No games found' : 'No games yet'}</h3>
          <p>{search ? 'Try a different search term.' : 'Click "Detect Launchers" to find installed games, or add folders in Settings.'}</p>
          {!search && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-primary" onClick={handleDetect}>
                <DetectIcon /> Detect Launchers
              </button>
              <button className="btn btn-secondary" onClick={() => setShowAdd(true)}>
                <PlusIcon /> Add Manually
              </button>
            </div>
          )}
        </div>
      ) : view === 'grid' ? (
        <div className="media-grid">
          {filtered.map(g => (
            <MediaCard
              key={g.id} item={g} type="games" thumbRatio="3/4"
              onPlay={() => launchGame(g)}
              onFavorite={() => toggleFavorite(g)}
              onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelectedGame(g); }}
            />
          ))}
        </div>
      ) : (
        <div className="media-list">
          {filtered.map((g, i) => (
            <MediaListItem
              key={g.id} item={g} type="games" index={i}
              onPlay={() => launchGame(g)}
              onFavorite={() => toggleFavorite(g)}
              onContextMenu={e => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY }); setSelectedGame(g); }}
            />
          ))}
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && selectedGame && (
        <ContextMenu
          x={contextMenu.x} y={contextMenu.y}
          onClose={() => setContextMenu(null)}
          items={[
            { label: 'Launch', icon: '▶', onClick: () => launchGame(selectedGame) },
            { label: selectedGame.is_favorite ? 'Remove Favorite' : 'Add to Favorites', icon: '♥', onClick: () => toggleFavorite(selectedGame) },
            { sep: true },
            { label: 'Show in Explorer', icon: '📁', onClick: () => openFolder(selectedGame) },
            { sep: true },
            { label: 'Remove from Library', danger: true, icon: '✕', onClick: () => deleteGame(selectedGame) },
          ]}
        />
      )}

      {/* Add Game Modal */}
      {showAdd && (
        <AddGameModal
          onClose={() => setShowAdd(false)}
          onAdd={() => { setShowAdd(false); load(); }}
        />
      )}
    </div>
  );
}
