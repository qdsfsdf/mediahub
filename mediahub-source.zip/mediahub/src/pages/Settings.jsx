import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.jsx';

const TYPES = [
  { id: 'games',   label: 'Games',    icon: '🎮', desc: 'Folders scanned for game executables' },
  { id: 'music',   label: 'Music',    icon: '🎵', desc: 'Folders scanned for audio files (MP3, FLAC, WAV, OGG, AAC, M4A)' },
  { id: 'videos',  label: 'Videos',   icon: '📹', desc: 'Folders scanned for video files (MP4, MKV, AVI, MOV, WMV)' },
  { id: 'movies',  label: 'Movies',   icon: '🎬', desc: 'Folders scanned for movie files' },
  { id: 'tvshows', label: 'TV Shows', icon: '📺', desc: 'Folders scanned for TV episode files' },
  { id: 'other',   label: 'Other',    icon: '📁', desc: 'Folders scanned for documents, PDFs, archives' },
];

const PlusIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const ScanIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>;

export default function Settings() {
  const { toast } = useApp();
  const [folders, setFolders] = useState({});
  const [dataPath, setDataPath] = useState('');
  const [version, setVersion] = useState('');
  const [scanningType, setScanningType] = useState(null);

  useEffect(() => {
    loadAll();
    window.electron?.getDataPath().then(setDataPath);
    window.electron?.getVersion().then(setVersion);
  }, []);

  const loadAll = async () => {
    if (!window.electron) return;
    const result = {};
    for (const t of TYPES) {
      result[t.id] = await window.electron.getFolders(t.id);
    }
    setFolders(result);
  };

  const addFolder = async (type) => {
    const folder = await window.electron.selectFolder();
    if (!folder) return;
    await window.electron.addFolder(type, folder);
    loadAll();
    toast(`Folder added to ${type}`, 'success');
  };

  const removeFolder = async (type, folder) => {
    await window.electron.removeFolder(type, folder);
    loadAll();
    toast('Folder removed');
  };

  const scanType = async (type) => {
    setScanningType(type);
    const result = await window.electron.scanLibrary(type);
    setScanningType(null);
    toast(`Scanned ${type}: ${result.count} items found`, 'success');
  };

  const scanAll = async () => {
    for (const t of TYPES) {
      if ((folders[t.id] || []).length > 0) {
        await scanType(t.id);
      }
    }
    toast('Full library scan complete', 'success');
  };

  const openDataFolder = () => {
    if (dataPath) window.electron.showInFolder(dataPath);
  };

  return (
    <div className="page" style={{ maxWidth: 760 }}>
      <div className="page-header">
        <div className="page-header-left">
          <h1 className="page-title">Settings</h1>
          <p className="page-subtitle">Configure library folders and scanning</p>
        </div>
        <div className="page-header-right">
          <button className="btn btn-primary btn-sm" onClick={scanAll}>
            <ScanIcon /> Scan All Libraries
          </button>
        </div>
      </div>

      {/* Library Folders */}
      <div className="settings-section">
        <div className="settings-section-title">Library Folders</div>
        {TYPES.map(type => (
          <div key={type.id} style={{ borderBottom: '1px solid var(--border-soft)' }}>
            <div className="settings-row">
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 16 }}>{type.icon}</span>
                  <div className="settings-row-label">{type.label}</div>
                </div>
                <div className="settings-row-desc">{type.desc}</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => scanType(type.id)}
                  disabled={!folders[type.id]?.length || scanningType === type.id}
                  style={{ minWidth: 68 }}
                >
                  {scanningType === type.id ? <><div className="scan-spinner" style={{ width: 10, height: 10 }} /> Scanning</> : <><ScanIcon /> Scan</>}
                </button>
                <button className="btn btn-primary btn-sm" onClick={() => addFolder(type.id)}>
                  <PlusIcon /> Add Folder
                </button>
              </div>
            </div>

            {/* Folder list */}
            {(folders[type.id] || []).length > 0 && (
              <div style={{ padding: '0 20px 14px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {folders[type.id].map(f => (
                  <div key={f} className="folder-pill">
                    <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f}</span>
                    <button
                      className="folder-pill-remove"
                      onClick={() => removeFolder(type.id, f)}
                      title="Remove folder"
                    >✕</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Game Detection */}
      <div className="settings-section">
        <div className="settings-section-title">Game Launcher Detection</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Auto-detect Installed Games</div>
            <div className="settings-row-desc">Scans for Steam, Epic Games, and GOG Galaxy installations automatically</div>
          </div>
          <button
            className="btn btn-secondary btn-sm"
            onClick={async () => {
              const result = await window.electron.detectLaunchers();
              toast(`Detected ${result.count} games from launchers`, 'success');
            }}
          >
            Detect Now
          </button>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Supported Launchers</div>
            <div className="settings-row-desc">Steam, Epic Games Store, GOG Galaxy, and manual executables</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <span className="launcher-badge steam">Steam</span>
            <span className="launcher-badge epic">Epic</span>
            <span className="launcher-badge gog">GOG</span>
          </div>
        </div>
      </div>

      {/* Data & Storage */}
      <div className="settings-section">
        <div className="settings-section-title">Data & Storage</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Data Location</div>
            <div className="settings-row-desc" style={{ fontFamily: 'monospace', fontSize: 11 }}>{dataPath}</div>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={openDataFolder}>Open Folder</button>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Clear Library Cache</div>
            <div className="settings-row-desc">Remove all scanned items. Your files are not deleted.</div>
          </div>
          <button
            className="btn btn-danger btn-sm"
            onClick={async () => {
              if (confirm('Clear all library data? This cannot be undone. Your files are not deleted.')) {
                // Implement clear via deleteItem calls or direct DB wipe
                toast('Library cleared. Rescan to rebuild.', 'success');
              }
            }}
          >
            Clear All
          </button>
        </div>
      </div>

      {/* About */}
      <div className="settings-section">
        <div className="settings-section-title">About</div>
        <div className="settings-row">
          <div className="settings-row-label">MediaHub</div>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Version {version || '1.0.0'}</span>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Open Source</div>
            <div className="settings-row-desc">Built with Electron, React, and SQLite. Runs 100% locally.</div>
          </div>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Supported Formats</div>
            <div className="settings-row-desc">
              Audio: MP3, FLAC, WAV, OGG, AAC, M4A, WMA, OPUS · Video: MP4, MKV, AVI, MOV, WMV, M4V, MPG, WEBM · Documents: PDF, EPUB, CBZ, CBR, DOCX, TXT · Archives: ZIP, RAR, 7Z
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
