const { app, BrowserWindow, ipcMain, dialog, shell, protocol, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const isDev = process.env.NODE_ENV === 'development';

// Lazy-load heavy modules
let db, scanner;
function getDB() { if (!db) db = require('./db'); return db; }
function getScanner() { if (!scanner) scanner = require('./scanner'); return scanner; }

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#07070f',
    show: false,
    icon: path.join(__dirname, '../build/icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false,
      allowRunningInsecureContent: false
    }
  });

  Menu.setApplicationMenu(null);

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    // mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

// Register media file protocol
app.whenReady().then(() => {
  protocol.registerFileProtocol('media', (request, callback) => {
    const url = request.url.replace('media://', '');
    const decoded = decodeURIComponent(url);
    callback({ path: decoded });
  });

  getDB().init();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ─── Window Controls ──────────────────────────────────────────────────────────
ipcMain.on('minimize-window', () => mainWindow?.minimize());
ipcMain.on('maximize-window', () => {
  if (mainWindow?.isMaximized()) mainWindow.restore();
  else mainWindow?.maximize();
});
ipcMain.on('close-window', () => mainWindow?.close());

// ─── App Info ─────────────────────────────────────────────────────────────────
ipcMain.handle('get-app-version', () => app.getVersion());
ipcMain.handle('get-data-path', () => app.getPath('userData'));

// ─── Dialog ───────────────────────────────────────────────────────────────────
ipcMain.handle('select-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory']
  });
  return result.canceled ? null : result.filePaths[0];
});

ipcMain.handle('select-file', async (_, filters) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: filters || [{ name: 'All Files', extensions: ['*'] }]
  });
  return result.canceled ? null : result.filePaths[0];
});

ipcMain.handle('select-image', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif'] }]
  });
  if (result.canceled) return null;
  const data = fs.readFileSync(result.filePaths[0]);
  const ext = path.extname(result.filePaths[0]).slice(1).toLowerCase();
  const mime = ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : `image/${ext}`;
  return `data:${mime};base64,${data.toString('base64')}`;
});

// ─── Settings ────────────────────────────────────────────────────────────────
ipcMain.handle('get-settings', () => getDB().getAllSettings());
ipcMain.handle('get-setting', (_, key) => getDB().getSetting(key));
ipcMain.handle('set-setting', (_, key, value) => getDB().setSetting(key, value));

// ─── Folders ─────────────────────────────────────────────────────────────────
ipcMain.handle('get-folders', (_, type) => getDB().getFolders(type));
ipcMain.handle('add-folder', (_, type, folder) => getDB().addFolder(type, folder));
ipcMain.handle('remove-folder', (_, type, folder) => getDB().removeFolder(type, folder));

// ─── Library ─────────────────────────────────────────────────────────────────
ipcMain.handle('get-library', (_, type) => getDB().getLibrary(type));

ipcMain.handle('scan-library', async (_, type) => {
  const folders = getDB().getFolders(type);
  if (!folders.length) return { count: 0, message: 'No folders configured' };

  const sc = getScanner();
  let items = [];

  if (type === 'games') {
    items = await sc.scanGames(folders, mainWindow);
  } else if (type === 'music') {
    items = await sc.scanMusic(folders, mainWindow);
  } else if (['videos', 'movies', 'tvshows'].includes(type)) {
    items = await sc.scanVideos(folders, type, mainWindow);
  } else if (type === 'other') {
    items = await sc.scanOther(folders, mainWindow);
  }

  getDB().bulkUpsertLibrary(type, items);
  return { count: items.length };
});

ipcMain.handle('detect-launchers', async () => {
  const sc = getScanner();
  const games = await sc.detectLaunchers();
  if (games.length) {
    getDB().bulkUpsertLibrary('games', games);
  }
  return { count: games.length };
});

// ─── Items ───────────────────────────────────────────────────────────────────
ipcMain.handle('add-item', (_, type, data) => getDB().addItem(type, data));
ipcMain.handle('update-item', (_, type, id, data) => getDB().updateItem(type, id, data));
ipcMain.handle('delete-item', (_, type, id) => getDB().deleteItem(type, id));
ipcMain.handle('get-item', (_, type, id) => getDB().getItem(type, id));

// ─── Favorites & Recent ──────────────────────────────────────────────────────
ipcMain.handle('toggle-favorite', (_, type, id) => getDB().toggleFavorite(type, id));
ipcMain.handle('get-favorites', (_, type) => getDB().getFavorites(type));
ipcMain.handle('add-recent', (_, type, id) => getDB().addRecent(type, id));
ipcMain.handle('get-recent', (_, type, limit) => getDB().getRecent(type, limit || 20));

// ─── Search ──────────────────────────────────────────────────────────────────
ipcMain.handle('search', (_, query) => getDB().search(query));

// ─── Playlists ───────────────────────────────────────────────────────────────
ipcMain.handle('get-playlists', () => getDB().getPlaylists());
ipcMain.handle('create-playlist', (_, name) => getDB().createPlaylist(name));
ipcMain.handle('delete-playlist', (_, id) => getDB().deletePlaylist(id));
ipcMain.handle('rename-playlist', (_, id, name) => getDB().renamePlaylist(id, name));
ipcMain.handle('get-playlist-tracks', (_, id) => getDB().getPlaylistTracks(id));
ipcMain.handle('add-to-playlist', (_, playlistId, trackId) => getDB().addToPlaylist(playlistId, trackId));
ipcMain.handle('remove-from-playlist', (_, playlistId, trackId) => getDB().removeFromPlaylist(playlistId, trackId));

// ─── Video Progress ───────────────────────────────────────────────────────────
ipcMain.handle('save-video-progress', (_, id, time) => getDB().saveVideoProgress(id, time));
ipcMain.handle('get-video-progress', (_, id) => getDB().getVideoProgress(id));

// ─── Launch / Open ────────────────────────────────────────────────────────────
ipcMain.handle('launch-game', async (_, execPath, args) => {
  try {
    const proc = spawn(execPath, args || [], {
      detached: true,
      stdio: 'ignore',
      cwd: path.dirname(execPath)
    });
    proc.unref();
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

ipcMain.handle('open-file', async (_, filePath) => {
  try {
    await shell.openPath(filePath);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

ipcMain.handle('show-in-folder', (_, filePath) => {
  shell.showItemInFolder(filePath);
});

// ─── Music Metadata ───────────────────────────────────────────────────────────
ipcMain.handle('get-music-metadata', async (_, filePath) => {
  try {
    const mm = require('music-metadata');
    const meta = await mm.parseFile(filePath, { duration: true, skipCovers: false });
    const pic = meta.common.picture?.[0];
    const artwork = pic
      ? `data:${pic.format};base64,${Buffer.from(pic.data).toString('base64')}`
      : null;
    return {
      title: meta.common.title || path.basename(filePath, path.extname(filePath)),
      artist: meta.common.artist || meta.common.albumartist || 'Unknown Artist',
      album: meta.common.album || 'Unknown Album',
      year: meta.common.year,
      genre: meta.common.genre?.[0],
      trackNo: meta.common.track?.no,
      duration: meta.format.duration || 0,
      bitrate: meta.format.bitrate,
      artwork
    };
  } catch {
    return {
      title: path.basename(filePath, path.extname(filePath)),
      artist: 'Unknown Artist',
      album: 'Unknown Album',
      duration: 0
    };
  }
});

// ─── Path utilities ───────────────────────────────────────────────────────────
ipcMain.handle('path-to-media-url', (_, filePath) => {
  const normalized = filePath.replace(/\\/g, '/');
  return `media://${encodeURIComponent(normalized)}`;
});

ipcMain.handle('file-exists', (_, filePath) => {
  try { return fs.existsSync(filePath); } catch { return false; }
});

ipcMain.handle('read-image-as-base64', (_, filePath) => {
  try {
    if (!fs.existsSync(filePath)) return null;
    const data = fs.readFileSync(filePath);
    const ext = path.extname(filePath).slice(1).toLowerCase();
    const mime = ['jpg','jpeg'].includes(ext) ? 'image/jpeg' : `image/${ext}`;
    return `data:${mime};base64,${data.toString('base64')}`;
  } catch { return null; }
});
