const path = require('path');
const { app } = require('electron');

let db;

function init() {
  const Database = require('better-sqlite3');
  const dbPath = path.join(app.getPath('userData'), 'mediahub.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  createSchema();
  console.log('Database initialized at:', dbPath);
}

function createSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      path TEXT NOT NULL,
      UNIQUE(type, path)
    );

    CREATE TABLE IF NOT EXISTS library (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      file_path TEXT,
      cover_art TEXT,
      metadata TEXT,
      is_favorite INTEGER DEFAULT 0,
      date_added INTEGER DEFAULT (strftime('%s','now')),
      last_opened INTEGER,
      UNIQUE(type, file_path)
    );

    CREATE TABLE IF NOT EXISTS favorites (
      type TEXT,
      item_id INTEGER,
      PRIMARY KEY(type, item_id)
    );

    CREATE TABLE IF NOT EXISTS recently_opened (
      type TEXT,
      item_id INTEGER,
      opened_at INTEGER DEFAULT (strftime('%s','now')),
      PRIMARY KEY(type, item_id)
    );

    CREATE TABLE IF NOT EXISTS video_progress (
      item_id INTEGER PRIMARY KEY,
      progress REAL DEFAULT 0,
      updated_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS playlists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS playlist_tracks (
      playlist_id INTEGER REFERENCES playlists(id) ON DELETE CASCADE,
      track_id INTEGER,
      position INTEGER,
      PRIMARY KEY(playlist_id, track_id)
    );

    CREATE INDEX IF NOT EXISTS idx_library_type ON library(type);
    CREATE INDEX IF NOT EXISTS idx_library_title ON library(title);
    CREATE INDEX IF NOT EXISTS idx_recently_opened ON recently_opened(opened_at DESC);
  `);
}

// ─── Settings ─────────────────────────────────────────────────────────────────
function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  try { return row ? JSON.parse(row.value) : null; }
  catch { return row?.value ?? null; }
}

function setSetting(key, value) {
  db.prepare('INSERT OR REPLACE INTO settings(key, value) VALUES(?,?)').run(key, JSON.stringify(value));
  return true;
}

function getAllSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const result = {};
  for (const row of rows) {
    try { result[row.key] = JSON.parse(row.value); }
    catch { result[row.key] = row.value; }
  }
  return result;
}

// ─── Folders ──────────────────────────────────────────────────────────────────
function getFolders(type) {
  return db.prepare('SELECT path FROM folders WHERE type = ?').all(type).map(r => r.path);
}

function addFolder(type, folderPath) {
  try {
    db.prepare('INSERT OR IGNORE INTO folders(type, path) VALUES(?,?)').run(type, folderPath);
    return true;
  } catch { return false; }
}

function removeFolder(type, folderPath) {
  db.prepare('DELETE FROM folders WHERE type=? AND path=?').run(type, folderPath);
  return true;
}

// ─── Library ──────────────────────────────────────────────────────────────────
function getLibrary(type) {
  const rows = db.prepare(`
    SELECT l.*, 
      CASE WHEN f.item_id IS NOT NULL THEN 1 ELSE 0 END as is_favorite,
      vp.progress as video_progress
    FROM library l
    LEFT JOIN favorites f ON f.type = l.type AND f.item_id = l.id
    LEFT JOIN video_progress vp ON vp.item_id = l.id
    WHERE l.type = ?
    ORDER BY l.title ASC
  `).all(type);

  return rows.map(row => ({
    ...row,
    metadata: row.metadata ? JSON.parse(row.metadata) : {}
  }));
}

function bulkUpsertLibrary(type, items) {
  const upsert = db.prepare(`
    INSERT INTO library(type, title, file_path, cover_art, metadata)
    VALUES(@type, @title, @file_path, @cover_art, @metadata)
    ON CONFLICT(type, file_path) DO UPDATE SET
      title = excluded.title,
      cover_art = COALESCE(excluded.cover_art, cover_art),
      metadata = excluded.metadata
  `);

  const tx = db.transaction((items) => {
    for (const item of items) {
      upsert.run({
        type,
        title: item.title || 'Unknown',
        file_path: item.file_path || item.filePath || '',
        cover_art: item.cover_art || item.coverArt || null,
        metadata: JSON.stringify(item.metadata || {})
      });
    }
  });

  tx(items);
  return items.length;
}

function addItem(type, data) {
  const stmt = db.prepare(`
    INSERT INTO library(type, title, file_path, cover_art, metadata)
    VALUES(?,?,?,?,?)
  `);
  const result = stmt.run(type, data.title, data.file_path || '', data.cover_art || null, JSON.stringify(data.metadata || {}));
  return result.lastInsertRowid;
}

function updateItem(type, id, data) {
  const fields = [];
  const values = [];
  if (data.title !== undefined) { fields.push('title=?'); values.push(data.title); }
  if (data.cover_art !== undefined) { fields.push('cover_art=?'); values.push(data.cover_art); }
  if (data.metadata !== undefined) { fields.push('metadata=?'); values.push(JSON.stringify(data.metadata)); }
  if (data.file_path !== undefined) { fields.push('file_path=?'); values.push(data.file_path); }
  if (!fields.length) return false;
  values.push(id, type);
  db.prepare(`UPDATE library SET ${fields.join(',')} WHERE id=? AND type=?`).run(...values);
  return true;
}

function deleteItem(type, id) {
  db.prepare('DELETE FROM library WHERE id=? AND type=?').run(id, type);
  return true;
}

function getItem(type, id) {
  const row = db.prepare('SELECT * FROM library WHERE id=? AND type=?').get(id, type);
  if (!row) return null;
  return { ...row, metadata: row.metadata ? JSON.parse(row.metadata) : {} };
}

// ─── Favorites ───────────────────────────────────────────────────────────────
function toggleFavorite(type, id) {
  const existing = db.prepare('SELECT 1 FROM favorites WHERE type=? AND item_id=?').get(type, id);
  if (existing) {
    db.prepare('DELETE FROM favorites WHERE type=? AND item_id=?').run(type, id);
    return false;
  } else {
    db.prepare('INSERT OR IGNORE INTO favorites(type, item_id) VALUES(?,?)').run(type, id);
    return true;
  }
}

function getFavorites(type) {
  if (type) {
    return db.prepare(`
      SELECT l.*, 1 as is_favorite FROM library l
      JOIN favorites f ON f.type=l.type AND f.item_id=l.id
      WHERE l.type=?
    `).all(type).map(r => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : {} }));
  }
  return db.prepare(`
    SELECT l.*, 1 as is_favorite FROM library l
    JOIN favorites f ON f.type=l.type AND f.item_id=l.id
  `).all().map(r => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : {} }));
}

// ─── Recently Opened ─────────────────────────────────────────────────────────
function addRecent(type, id) {
  db.prepare(`
    INSERT OR REPLACE INTO recently_opened(type, item_id, opened_at)
    VALUES(?,?,strftime('%s','now'))
  `).run(type, id);
  db.prepare(`
    DELETE FROM recently_opened WHERE type=? AND item_id NOT IN (
      SELECT item_id FROM recently_opened WHERE type=? ORDER BY opened_at DESC LIMIT 50
    )
  `).run(type, type);
  db.prepare('UPDATE library SET last_opened=strftime(\'%s\',\'now\') WHERE id=?').run(id);
}

function getRecent(type, limit = 20) {
  const query = type
    ? `SELECT l.*, ro.opened_at FROM library l
       JOIN recently_opened ro ON ro.type=l.type AND ro.item_id=l.id
       WHERE l.type=? ORDER BY ro.opened_at DESC LIMIT ?`
    : `SELECT l.*, ro.opened_at FROM library l
       JOIN recently_opened ro ON ro.type=l.type AND ro.item_id=l.id
       ORDER BY ro.opened_at DESC LIMIT ?`;
  const args = type ? [type, limit] : [limit];
  return db.prepare(query).all(...args).map(r => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : {} }));
}

// ─── Video Progress ──────────────────────────────────────────────────────────
function saveVideoProgress(id, progress) {
  db.prepare(`
    INSERT OR REPLACE INTO video_progress(item_id, progress, updated_at)
    VALUES(?,?,strftime('%s','now'))
  `).run(id, progress);
}

function getVideoProgress(id) {
  const row = db.prepare('SELECT progress FROM video_progress WHERE item_id=?').get(id);
  return row?.progress ?? 0;
}

// ─── Search ──────────────────────────────────────────────────────────────────
function search(query) {
  const like = `%${query}%`;
  return db.prepare(`
    SELECT * FROM library WHERE title LIKE ? OR metadata LIKE ?
    ORDER BY title ASC LIMIT 50
  `).all(like, like).map(r => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : {} }));
}

// ─── Playlists ───────────────────────────────────────────────────────────────
function getPlaylists() {
  return db.prepare('SELECT *, (SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id=p.id) as track_count FROM playlists p ORDER BY name ASC').all();
}

function createPlaylist(name) {
  const result = db.prepare('INSERT INTO playlists(name) VALUES(?)').run(name);
  return result.lastInsertRowid;
}

function deletePlaylist(id) {
  db.prepare('DELETE FROM playlists WHERE id=?').run(id);
}

function renamePlaylist(id, name) {
  db.prepare('UPDATE playlists SET name=? WHERE id=?').run(name, id);
}

function getPlaylistTracks(playlistId) {
  return db.prepare(`
    SELECT l.*, pt.position FROM library l
    JOIN playlist_tracks pt ON pt.track_id=l.id
    WHERE pt.playlist_id=?
    ORDER BY pt.position ASC
  `).all(playlistId).map(r => ({ ...r, metadata: r.metadata ? JSON.parse(r.metadata) : {} }));
}

function addToPlaylist(playlistId, trackId) {
  const maxPos = db.prepare('SELECT MAX(position) as m FROM playlist_tracks WHERE playlist_id=?').get(playlistId);
  const pos = (maxPos?.m ?? -1) + 1;
  db.prepare('INSERT OR IGNORE INTO playlist_tracks(playlist_id, track_id, position) VALUES(?,?,?)').run(playlistId, trackId, pos);
}

function removeFromPlaylist(playlistId, trackId) {
  db.prepare('DELETE FROM playlist_tracks WHERE playlist_id=? AND track_id=?').run(playlistId, trackId);
}

module.exports = {
  init, getSetting, setSetting, getAllSettings,
  getFolders, addFolder, removeFolder,
  getLibrary, bulkUpsertLibrary, addItem, updateItem, deleteItem, getItem,
  toggleFavorite, getFavorites,
  addRecent, getRecent,
  saveVideoProgress, getVideoProgress,
  search,
  getPlaylists, createPlaylist, deletePlaylist, renamePlaylist,
  getPlaylistTracks, addToPlaylist, removeFromPlaylist
};
