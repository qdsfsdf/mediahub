const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  // Window
  minimize: () => ipcRenderer.send('minimize-window'),
  maximize: () => ipcRenderer.send('maximize-window'),
  close: () => ipcRenderer.send('close-window'),

  // App
  getVersion: () => ipcRenderer.invoke('get-app-version'),
  getDataPath: () => ipcRenderer.invoke('get-data-path'),

  // Dialogs
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  selectFile: (filters) => ipcRenderer.invoke('select-file', filters),
  selectImage: () => ipcRenderer.invoke('select-image'),

  // Settings
  getSettings: () => ipcRenderer.invoke('get-settings'),
  getSetting: (key) => ipcRenderer.invoke('get-setting', key),
  setSetting: (key, value) => ipcRenderer.invoke('set-setting', key, value),

  // Folders
  getFolders: (type) => ipcRenderer.invoke('get-folders', type),
  addFolder: (type, folder) => ipcRenderer.invoke('add-folder', type, folder),
  removeFolder: (type, folder) => ipcRenderer.invoke('remove-folder', type, folder),

  // Library
  getLibrary: (type) => ipcRenderer.invoke('get-library', type),
  scanLibrary: (type) => ipcRenderer.invoke('scan-library', type),
  detectLaunchers: () => ipcRenderer.invoke('detect-launchers'),

  // Items
  addItem: (type, data) => ipcRenderer.invoke('add-item', type, data),
  updateItem: (type, id, data) => ipcRenderer.invoke('update-item', type, id, data),
  deleteItem: (type, id) => ipcRenderer.invoke('delete-item', type, id),
  getItem: (type, id) => ipcRenderer.invoke('get-item', type, id),

  // Favorites & Recent
  toggleFavorite: (type, id) => ipcRenderer.invoke('toggle-favorite', type, id),
  getFavorites: (type) => ipcRenderer.invoke('get-favorites', type),
  addRecent: (type, id) => ipcRenderer.invoke('add-recent', type, id),
  getRecent: (type, limit) => ipcRenderer.invoke('get-recent', type, limit),

  // Search
  search: (query) => ipcRenderer.invoke('search', query),

  // Playlists
  getPlaylists: () => ipcRenderer.invoke('get-playlists'),
  createPlaylist: (name) => ipcRenderer.invoke('create-playlist', name),
  deletePlaylist: (id) => ipcRenderer.invoke('delete-playlist', id),
  renamePlaylist: (id, name) => ipcRenderer.invoke('rename-playlist', id, name),
  getPlaylistTracks: (id) => ipcRenderer.invoke('get-playlist-tracks', id),
  addToPlaylist: (playlistId, trackId) => ipcRenderer.invoke('add-to-playlist', playlistId, trackId),
  removeFromPlaylist: (playlistId, trackId) => ipcRenderer.invoke('remove-from-playlist', playlistId, trackId),

  // Video progress
  saveVideoProgress: (id, time) => ipcRenderer.invoke('save-video-progress', id, time),
  getVideoProgress: (id) => ipcRenderer.invoke('get-video-progress', id),

  // Launch / Open
  launchGame: (execPath, args) => ipcRenderer.invoke('launch-game', execPath, args),
  openFile: (filePath) => ipcRenderer.invoke('open-file', filePath),
  showInFolder: (filePath) => ipcRenderer.invoke('show-in-folder', filePath),

  // Media / Files
  getMusicMetadata: (filePath) => ipcRenderer.invoke('get-music-metadata', filePath),
  pathToMediaUrl: (filePath) => ipcRenderer.invoke('path-to-media-url', filePath),
  fileExists: (filePath) => ipcRenderer.invoke('file-exists', filePath),
  readImageAsBase64: (filePath) => ipcRenderer.invoke('read-image-as-base64', filePath),

  // Scan progress events
  onScanProgress: (cb) => {
    const handler = (_, data) => cb(data);
    ipcRenderer.on('scan-progress', handler);
    return () => ipcRenderer.removeListener('scan-progress', handler);
  }
});
