const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const AUDIO_EXTS = new Set(['.mp3', '.flac', '.wav', '.ogg', '.aac', '.m4a', '.wma', '.opus', '.ape']);
const VIDEO_EXTS = new Set(['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.m4v', '.mpg', '.mpeg', '.webm', '.flv', '.ts']);
const OTHER_EXTS = new Set(['.pdf', '.epub', '.cbz', '.cbr', '.doc', '.docx', '.txt', '.zip', '.rar', '.7z']);
const MAX_DEPTH = 8;

// ─── Walk Directory ───────────────────────────────────────────────────────────
function* walkDir(dir, depth = 0) {
  if (depth > MAX_DEPTH) return;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return; }

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      // Skip hidden and system dirs
      if (entry.name.startsWith('.') || ['$Recycle.Bin', 'System Volume Information', 'node_modules', '.git'].includes(entry.name)) continue;
      yield* walkDir(fullPath, depth + 1);
    } else if (entry.isFile()) {
      yield fullPath;
    }
  }
}

function formatDuration(secs) {
  if (!secs) return '';
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`
               : `${m}:${String(s).padStart(2,'0')}`;
}

function humanSize(bytes) {
  const units = ['B','KB','MB','GB','TB'];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
  return `${bytes.toFixed(1)} ${units[i]}`;
}

// ─── Music Scanner ────────────────────────────────────────────────────────────
async function scanMusic(folders, win) {
  const mm = require('music-metadata');
  const results = [];
  let count = 0;

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    for (const filePath of walkDir(folder)) {
      const ext = path.extname(filePath).toLowerCase();
      if (!AUDIO_EXTS.has(ext)) continue;

      count++;
      if (win && count % 20 === 0) {
        win.webContents.send('scan-progress', { type: 'music', count, file: path.basename(filePath) });
      }

      let meta;
      try {
        meta = await mm.parseFile(filePath, { duration: true, skipCovers: false });
      } catch {
        meta = { common: {}, format: {} };
      }

      const pic = meta.common.picture?.[0];
      const artwork = pic
        ? `data:${pic.format};base64,${Buffer.from(pic.data).toString('base64')}`
        : null;

      const stat = fs.statSync(filePath);
      results.push({
        title: meta.common.title || path.basename(filePath, ext),
        file_path: filePath,
        cover_art: artwork,
        metadata: {
          artist: meta.common.artist || meta.common.albumartist || 'Unknown Artist',
          album: meta.common.album || 'Unknown Album',
          year: meta.common.year,
          genre: meta.common.genre?.[0],
          trackNo: meta.common.track?.no,
          diskNo: meta.common.disk?.no,
          duration: meta.format.duration || 0,
          durationStr: formatDuration(meta.format.duration),
          bitrate: meta.format.bitrate ? Math.round(meta.format.bitrate / 1000) : null,
          format: ext.replace('.', '').toUpperCase(),
          size: humanSize(stat.size)
        }
      });
    }
  }

  return results;
}

// ─── Video Scanner ────────────────────────────────────────────────────────────
async function scanVideos(folders, type, win) {
  const results = [];
  let count = 0;

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    for (const filePath of walkDir(folder)) {
      const ext = path.extname(filePath).toLowerCase();
      if (!VIDEO_EXTS.has(ext)) continue;

      count++;
      if (win && count % 10 === 0) {
        win.webContents.send('scan-progress', { type, count, file: path.basename(filePath) });
      }

      const stat = fs.statSync(filePath);
      const basename = path.basename(filePath, ext);

      // Try to parse TV show info from filename
      let metadata = {
        format: ext.replace('.', '').toUpperCase(),
        size: humanSize(stat.size),
        modified: stat.mtime.toISOString()
      };

      if (type === 'tvshows') {
        const tvMatch = basename.match(/^(.+?)[. _-][Ss](\d{1,2})[Ee](\d{1,2})/i);
        if (tvMatch) {
          metadata.series = tvMatch[1].replace(/[._]/g, ' ').trim();
          metadata.season = parseInt(tvMatch[2]);
          metadata.episode = parseInt(tvMatch[3]);
        } else {
          metadata.series = basename;
        }
      }

      // Look for poster/thumbnail image near the video
      const coverCandidates = [
        path.join(path.dirname(filePath), basename + '.jpg'),
        path.join(path.dirname(filePath), basename + '.png'),
        path.join(path.dirname(filePath), 'poster.jpg'),
        path.join(path.dirname(filePath), 'cover.jpg'),
        path.join(path.dirname(filePath), 'folder.jpg'),
        path.join(path.dirname(filePath), 'thumb.jpg'),
      ];

      let coverArt = null;
      for (const c of coverCandidates) {
        if (fs.existsSync(c)) {
          try {
            const data = fs.readFileSync(c);
            const ext2 = path.extname(c).slice(1).toLowerCase();
            const mime = ext2 === 'jpg' ? 'image/jpeg' : `image/${ext2}`;
            coverArt = `data:${mime};base64,${data.toString('base64')}`;
            break;
          } catch { /* skip */ }
        }
      }

      results.push({
        title: basename,
        file_path: filePath,
        cover_art: coverArt,
        metadata
      });
    }
  }

  return results;
}

// ─── Other Files Scanner ──────────────────────────────────────────────────────
async function scanOther(folders, win) {
  const results = [];
  let count = 0;

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    for (const filePath of walkDir(folder)) {
      const ext = path.extname(filePath).toLowerCase();
      if (!OTHER_EXTS.has(ext)) continue;

      count++;
      if (win && count % 50 === 0) {
        win.webContents.send('scan-progress', { type: 'other', count, file: path.basename(filePath) });
      }

      const stat = fs.statSync(filePath);
      results.push({
        title: path.basename(filePath),
        file_path: filePath,
        cover_art: null,
        metadata: {
          format: ext.replace('.', '').toUpperCase(),
          size: humanSize(stat.size),
          modified: stat.mtime.toISOString(),
          directory: path.dirname(filePath)
        }
      });
    }
  }

  return results;
}

// ─── Game Scanner (manual folders) ───────────────────────────────────────────
async function scanGames(folders, win) {
  const results = [];
  let count = 0;

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    // Look for executables 2 levels deep
    let entries;
    try { entries = fs.readdirSync(folder, { withFileTypes: true }); }
    catch { continue; }

    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const gameDir = path.join(folder, entry.name);

      // Find main exe in this dir
      let exeFiles;
      try { exeFiles = fs.readdirSync(gameDir).filter(f => f.endsWith('.exe')); }
      catch { continue; }

      if (!exeFiles.length) continue;

      // Pick the most likely game exe (not installer/uninstaller)
      const ignored = /install|uninstall|setup|uninst|redist|vcredist|directx|crash|report|helper|launcher_old/i;
      const main = exeFiles.find(f => !ignored.test(f)) || exeFiles[0];

      // Look for cover art
      const coverCandidates = ['header.jpg', 'cover.jpg', 'boxart.jpg', 'poster.jpg', 'banner.jpg',
                               'header.png', 'cover.png', 'background.jpg', 'background.png'].map(c => path.join(gameDir, c));
      let coverArt = null;
      for (const c of coverCandidates) {
        if (fs.existsSync(c)) {
          try {
            const data = fs.readFileSync(c);
            const ext = path.extname(c).slice(1).toLowerCase();
            const mime = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
            coverArt = `data:${mime};base64,${data.toString('base64')}`;
            break;
          } catch { /* skip */ }
        }
      }

      count++;
      if (win) win.webContents.send('scan-progress', { type: 'games', count, file: entry.name });

      results.push({
        title: entry.name.replace(/[_\-]/g, ' '),
        file_path: path.join(gameDir, main),
        cover_art: coverArt,
        metadata: {
          directory: gameDir,
          launcher: 'manual',
          exeFiles
        }
      });
    }
  }

  return results;
}

// ─── VDF Parser (Steam) ───────────────────────────────────────────────────────
function parseVDF(content) {
  const result = {};
  const lines = content.split(/\r?\n/);
  const stack = [result];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line || line.startsWith('//')) continue;

    if (line === '{') continue;
    if (line === '}') { if (stack.length > 1) stack.pop(); continue; }

    const pairMatch = line.match(/^"([^"]+)"\s+"([^"]*)"$/);
    if (pairMatch) {
      stack[stack.length - 1][pairMatch[1]] = pairMatch[2];
      continue;
    }

    const keyMatch = line.match(/^"([^"]+)"$/);
    if (keyMatch) {
      const obj = {};
      stack[stack.length - 1][keyMatch[1]] = obj;
      stack.push(obj);
    }
  }

  return result;
}

// ─── Launcher Detector ────────────────────────────────────────────────────────
async function detectLaunchers() {
  const games = [];

  // Steam
  try {
    const steamPaths = [
      'C:\\Program Files (x86)\\Steam',
      'C:\\Program Files\\Steam',
      path.join(process.env.USERPROFILE || '', '.steam', 'steam')
    ];

    for (const steamPath of steamPaths) {
      if (!fs.existsSync(steamPath)) continue;

      const vdfPath = path.join(steamPath, 'steamapps', 'libraryfolders.vdf');
      if (!fs.existsSync(vdfPath)) continue;

      const vdfContent = fs.readFileSync(vdfPath, 'utf-8');
      const vdfData = parseVDF(vdfContent);

      // Collect all library paths
      const libraryPaths = [path.join(steamPath, 'steamapps')];

      const folders = vdfData['libraryfolders'] || vdfData['LibraryFolders'] || {};
      for (const key of Object.keys(folders)) {
        const entry = folders[key];
        if (typeof entry === 'object' && entry.path) {
          libraryPaths.push(path.join(entry.path, 'steamapps'));
        } else if (typeof entry === 'string' && /^\d+$/.test(key)) {
          libraryPaths.push(path.join(entry, 'steamapps'));
        }
      }

      for (const libPath of libraryPaths) {
        if (!fs.existsSync(libPath)) continue;

        let manifests;
        try { manifests = fs.readdirSync(libPath).filter(f => f.startsWith('appmanifest_') && f.endsWith('.acf')); }
        catch { continue; }

        for (const manifest of manifests) {
          try {
            const content = fs.readFileSync(path.join(libPath, manifest), 'utf-8');
            const data = parseVDF(content);
            const appState = data['AppState'] || data['appstate'] || {};

            const appId = appState.appid || appState.AppID;
            const name = appState.name || appState.Name;
            const installDir = appState.installdir || appState.InstallDir;

            if (!name || !installDir) continue;

            const gameDir = path.join(libPath, 'common', installDir);
            if (!fs.existsSync(gameDir)) continue;

            // Find exe
            let exeFiles;
            try { exeFiles = fs.readdirSync(gameDir).filter(f => f.endsWith('.exe')); }
            catch { exeFiles = []; }
            const ignored = /install|uninstall|setup|uninst|crash|helper/i;
            const mainExe = exeFiles.find(f => !ignored.test(f)) || exeFiles[0];

            // Steam cover art from cache
            const steamCachePath = path.join(steamPath, 'appcache', 'librarycache', `${appId}_library_600x900.jpg`);
            const steamHeaderPath = path.join(steamPath, 'appcache', 'librarycache', `${appId}_header.jpg`);
            let coverArt = null;

            for (const imgPath of [steamCachePath, steamHeaderPath]) {
              if (fs.existsSync(imgPath)) {
                try {
                  const data2 = fs.readFileSync(imgPath);
                  coverArt = `data:image/jpeg;base64,${data2.toString('base64')}`;
                  break;
                } catch { /* skip */ }
              }
            }

            games.push({
              title: name,
              file_path: mainExe ? path.join(gameDir, mainExe) : gameDir,
              cover_art: coverArt,
              metadata: {
                launcher: 'steam',
                steamAppId: appId,
                steamUrl: `steam://rungameid/${appId}`,
                directory: gameDir,
                exeFiles
              }
            });
          } catch { /* skip bad manifest */ }
        }
      }
    }
  } catch (e) {
    console.log('Steam detection error:', e.message);
  }

  // Epic Games Store
  try {
    const epicManifestPath = path.join(
      process.env.PROGRAMDATA || 'C:\\ProgramData',
      'Epic', 'EpicGamesLauncher', 'Data', 'Manifests'
    );

    if (fs.existsSync(epicManifestPath)) {
      const items = fs.readdirSync(epicManifestPath).filter(f => f.endsWith('.item'));

      for (const item of items) {
        try {
          const content = fs.readFileSync(path.join(epicManifestPath, item), 'utf-8');
          const data = JSON.parse(content);

          if (!data.bIsIncompleteInstall && data.DisplayName && data.InstallLocation) {
            const exePath = data.LaunchExecutable
              ? path.join(data.InstallLocation, data.LaunchExecutable)
              : null;

            games.push({
              title: data.DisplayName,
              file_path: exePath || data.InstallLocation,
              cover_art: null,
              metadata: {
                launcher: 'epic',
                epicId: data.CatalogItemId,
                directory: data.InstallLocation,
                namespace: data.CatalogNamespace
              }
            });
          }
        } catch { /* skip */ }
      }
    }
  } catch (e) {
    console.log('Epic detection error:', e.message);
  }

  // GOG Galaxy
  try {
    const gogPaths = [
      'C:\\Program Files (x86)\\GOG Galaxy\\games',
      'C:\\Program Files\\GOG Galaxy\\games',
      'C:\\GOG Games'
    ];

    for (const gogPath of gogPaths) {
      if (!fs.existsSync(gogPath)) continue;

      const gameDirs = fs.readdirSync(gogPath, { withFileTypes: true })
        .filter(e => e.isDirectory()).map(e => path.join(gogPath, e.name));

      for (const gameDir of gameDirs) {
        let exeFiles;
        try { exeFiles = fs.readdirSync(gameDir).filter(f => f.endsWith('.exe')); }
        catch { continue; }
        if (!exeFiles.length) continue;

        const ignored = /install|uninstall|setup|galaxy/i;
        const mainExe = exeFiles.find(f => !ignored.test(f)) || exeFiles[0];

        const gogInfoPath = path.join(gameDir, 'goggame-*.info');
        let title = path.basename(gameDir);

        // Try reading GOG info file
        try {
          const infoFiles = fs.readdirSync(gameDir).filter(f => f.startsWith('goggame-') && f.endsWith('.info'));
          if (infoFiles.length) {
            const info = JSON.parse(fs.readFileSync(path.join(gameDir, infoFiles[0]), 'utf-8'));
            title = info.gameId || title;
          }
        } catch { /* skip */ }

        games.push({
          title,
          file_path: path.join(gameDir, mainExe),
          cover_art: null,
          metadata: { launcher: 'gog', directory: gameDir, exeFiles }
        });
      }
    }
  } catch (e) {
    console.log('GOG detection error:', e.message);
  }

  return games;
}

module.exports = { scanGames, scanMusic, scanVideos, scanOther, detectLaunchers };
